# Reading Guide Browser Extension

A digital version of the physical translucent reading guide — a tinted overlay with a clear focus strip and underline that helps you track lines of text while reading. Navigates line-by-line through the actual rendered text, including wrapped lines within paragraphs.

---

## Installation (Chrome / Edge / Brave)

1. Open your browser and go to `chrome://extensions`
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `reading-guide-extension` folder
5. The extension icon will appear in your toolbar

---

## Usage

### Placing your reading line

- Press **Alt+L** anywhere on the page — your cursor becomes a crosshair, click to place the line
- Or click the extension icon → **"Click to place reading line"**
- Or click the extension icon → flip the toggle **ON** to activate at the current scroll position

### Moving the line

- **↓ Arrow** — move down one line
- **↑ Arrow** — move up one line

Navigation follows actual rendered lines, including wrapped text within long paragraphs. Arrow keys are ignored when focus is in a text field.

### Turning it off

- Press **Esc** on the page
- Or flip the toggle in the popup

---

## Settings

Settings are grouped into three collapsible sections in the popup. All settings save automatically and persist across sessions and page loads.

### Overlay

| Setting | Description |
|---|---|
| Tint Opacity | How dark the overlay is above and below the reading strip |
| Strip Height | Height of the clear reading window. Auto-detected on activation |
| Line Step | Fallback step size when DOM navigation is unavailable |
| Tint Color | Color of the overlay tint |
| Link Underline to Tint | Automatically derives the underline color from the tint |
| Underline Color | Color of the focus underline (unlocked when link is off) |

### Typography

Applies to the current page immediately. Useful for readability and dyslexia support.

| Setting | Description |
|---|---|
| Font Override | Replace the page font. Options: Off, Atkinson Hyperlegible, OpenDyslexic, Lexie Readable, Comic Sans, Verdana |
| Letter Spacing | Increases spacing between characters (0–0.20em) |
| Line Height | Increases line height (1.4× to 2.4×) |

Font overrides use bundled font files and apply with high specificity. Icon fonts (Font Awesome, Material Icons, etc.) are automatically excluded.

### Scroll

| Setting | Description |
|---|---|
| Scroll Zone | How close to the edge of the viewport the line gets before the page scrolls (5–50% of viewport height). Increase this if a large sticky footer is eating into the readable area |
| Scroll Mode | **Center** — scrolls the next line to the middle of the screen. **Fixed Line** — the page scrolls under the line so the underline appears stationary |

---

## Tips

- **Alt+L** is the fastest way to start reading — click once to place, then use arrow keys
- **Strip Height** is auto-detected when you activate; adjust it if the strip doesn't match your font size
- On sites with large sticky headers or footers, increase **Scroll Zone** so the line doesn't get obscured before scrolling kicks in
- **Fixed Line** scroll mode feels most like a physical reading ruler — the text moves, the line stays put
- **Atkinson Hyperlegible** is a good general-purpose legibility font; **OpenDyslexic** and **Lexie Readable** are designed specifically for dyslexic readers
- Increasing **Letter Spacing** and **Line Height** together often has more impact than font choice alone
- The **Alt+L** shortcut can be reassigned at `chrome://extensions/shortcuts`

---

## Known Limitations

- Does not work inside cross-origin iframes
- Chrome's built-in PDF viewer is sandboxed — the overlay won't appear on PDF pages
- Some sites with extremely high z-index elements may appear above the overlay
- Font overrides use `!important` and high-specificity selectors; a small number of sites with inline styles may resist them