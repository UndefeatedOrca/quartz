chrome.commands.onCommand.addListener((command) => {
  if (command === 'toggle-overlay') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_STATE' }, (res) => {
        if (chrome.runtime.lastError || !res) return;
        if (res.mouseMode) {
          // Mouse mode: Alt+R just toggles the overlay on/off with snap-to-nearest.
          // No pick mode — the line follows the cursor so placement isn't needed.
          chrome.tabs.sendMessage(tabs[0].id, { type: 'TOGGLE_OVERLAY' });
        } else {
          // Line mode: Alt+R enters pick mode to place/reposition the line.
          chrome.tabs.sendMessage(tabs[0].id, { type: 'ENTER_PICK_MODE' });
        }
      });
    });
  }
});