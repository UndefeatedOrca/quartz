const $ = id => document.getElementById(id);

// ─── Section collapse ─────────────────────────────────────────────────────────
document.querySelectorAll('.section-header').forEach(header => {
  header.addEventListener('click', () => {
    header.closest('.section').classList.toggle('open');
  });
});

// ─── Subsection collapse ──────────────────────────────────────────────────────
document.querySelectorAll('.subsection-header').forEach(header => {
  header.addEventListener('click', () => {
    header.closest('.subsection').classList.toggle('open');
  });
});

// ─── Tab messaging ────────────────────────────────────────────────────────────
function sendToTab(msg) {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return resolve(null);
      chrome.tabs.sendMessage(tabs[0].id, msg, (res) => {
        resolve(chrome.runtime.lastError ? null : res);
      });
    });
  });
}

// ─── Color helpers ────────────────────────────────────────────────────────────
function hexToRgbStr(hex) {
  return [1,3,5].map(i => parseInt(hex.slice(i, i+2), 16)).join(', ');
}
function rgbStrToHex(str) {
  return '#' + str.split(',').map(n =>
    Math.max(0,Math.min(255,parseInt(n.trim()))).toString(16).padStart(2,'0')
  ).join('');
}

// ─── Value display helpers ────────────────────────────────────────────────────
function fmtLetterSpacing(v) { return v == 0 ? 'off' : `+${(v/100).toFixed(2)}em`; }
let nativeLineHeight = 0; // populated from content script on activation

// Power curve for opacity slider: perceived brightness change is nonlinear.
// This curve gives fine control at low opacities (where most users sit) while
// still reaching near-blackout at the top end.
// sliderVal 0–100  →  opacity 0–0.95
function sliderToOpacity(v) { return Math.round((v / 100) ** 2 * 95) / 100; }
// opacity 0–0.95  →  sliderVal 0–100  (inverse of above)
function opacityToSlider(o) { return Math.round(Math.sqrt(o / 0.95) * 100); }
function fmtOpacityPct(v)   { return Math.round(sliderToOpacity(v) * 100) + '%'; }
function fmtLineHeight(v) {
  if (v == 0) return 'off';
  const floor = nativeLineHeight > 0 ? nativeLineHeight : 1.5;
  return '×' + (floor + v * 0.1).toFixed(1);
}
function fmtColumnWidth(v) {
  // slider 0–9: 0=off, 1–9 → 40,45,50,55,60,65,70,75,80% of viewport
  if (v == 0) return 'off';
  return (35 + v * 5) + '%';
}

// ─── Load stored settings ─────────────────────────────────────────────────────
chrome.storage.sync.get([
  'active','tintOpacity','stripHeight','step',
  'tintColor','underlineColor','linkedColors',
  'scrollMode',
  'stripTintEnabled','stripTintColor','stripTintOpacity',
  'fontOverride','letterSpacing','lineHeightOverride','mouseMode',
  'shadingEnabled','shadeColor','shadeOpacity',
  'nativeLineHeight','columnWidth',
], (data) => {
  if (data.active) {
    setToggleUI(true);
    // Query live strip height — it may have been auto-detected on this page
    // and differ from the stored value.
    sendToTab({ type: 'GET_STATE' }).then(res => {
      if (res?.stripHeight) {
        $('strip-height').value = res.stripHeight;
        $('strip-height-val').textContent = res.stripHeight + 'px';
      }

    });
  }

  if (data.tintOpacity !== undefined) {
    $('opacity').value = opacityToSlider(data.tintOpacity);
    $('opacity-val').textContent = Math.round(data.tintOpacity * 100) + '%';
  }
  if (data.stripHeight !== undefined) {
    $('strip-height').value = data.stripHeight;
    $('strip-height-val').textContent = data.stripHeight + 'px';
  }
  if (data.step !== undefined) {
    $('step').value = data.step;
    $('step-val').textContent = data.step + 'px';
  }
  if (data.tintColor) $('tint-color').value = rgbStrToHex(data.tintColor);
  if (data.underlineColor) $('line-color').value = data.underlineColor;

  const linked = data.linkedColors !== false;
  $('link-toggle').checked = linked;
  setLinkedUI(linked);

  if (data.scrollMode) {
    const r = document.querySelector(`input[name="scroll-mode"][value="${data.scrollMode}"]`);
    if (r) r.checked = true;
  }
  const isMouseMode = !!data.mouseMode;
  $('mouse-mode-toggle').checked = isMouseMode;
  setMouseModeUI(isMouseMode);
  if (data.stripHeight !== undefined) {
    $('mouse-strip-height').value = data.stripHeight;
    $('mouse-strip-height-val').textContent = data.stripHeight + 'px';
  }

  if (data.mouseSensor !== undefined) $('sensor-toggle').checked = !!data.mouseSensor;
  if (data.mouseSensorSide) {
    const r = document.querySelector(`input[name="sensor-side"][value="${data.mouseSensorSide}"]`);
    if (r) r.checked = true;
  }

  // Shading
  const shadingOn = !!data.shadingEnabled;
  $('shading-toggle').checked = shadingOn;
  setShadingControlsUI(shadingOn);
  if (data.shadeColor) $('shade-color').value = rgbStrToHex(data.shadeColor);
  if (data.shadeOpacity !== undefined) {
    const pct = Math.round(data.shadeOpacity * 100);
    $('shade-opacity').value = pct;
    $('shade-opacity-val').textContent = pct + '%';
  }
  if (data.nativeLineHeight) nativeLineHeight = data.nativeLineHeight;

  // Strip tint
  const stripTintOn = !!data.stripTintEnabled;
  $('strip-tint-toggle').checked = stripTintOn;
  setStripTintControlsUI(stripTintOn);
  if (data.stripTintColor) $('strip-tint-color').value = rgbStrToHex(data.stripTintColor);
  if (data.stripTintOpacity !== undefined) {
    $('strip-tint-opacity').value = opacityToSlider(data.stripTintOpacity);
    $('strip-tint-opacity-val').textContent = Math.round(data.stripTintOpacity * 100) + '%';
  }
  if (data.columnWidth !== undefined) {
    $('column-width').value = data.columnWidth;
    $('column-width-val').textContent = fmtColumnWidth(data.columnWidth);
  }
  // Re-render lineHeight display now we have nativeLineHeight
  if (data.lineHeightOverride !== undefined) {
    $('line-height-val').textContent = fmtLineHeight(data.lineHeightOverride);
  }

  const font = data.fontOverride || 'off';
  const fontRadio = document.querySelector(`input[name="font"][value="${font}"]`);
  if (fontRadio) fontRadio.checked = true;

  if (data.letterSpacing !== undefined) {
    $('letter-spacing').value = data.letterSpacing;
    $('letter-spacing-val').textContent = fmtLetterSpacing(data.letterSpacing);
  }
  if (data.lineHeightOverride !== undefined) {
    $('line-height-override').value = data.lineHeightOverride;
    $('line-height-val').textContent = fmtLineHeight(data.lineHeightOverride);
  }
});

// ─── UI state helpers ─────────────────────────────────────────────────────────
function setStripTintControlsUI(enabled) {
  const el = $('strip-tint-controls');
  if (el) el.classList.toggle('disabled', !enabled);
}

function setShadingControlsUI(enabled) {
  const el = $('shading-controls');
  if (el) el.classList.toggle('disabled', !enabled);
}

function setMouseModeUI(isMouseMode) {
  const controls = $('mouse-mode-controls');
  if (controls) controls.classList.toggle('disabled', !isMouseMode);
  // step-row is always visible inside mouse-mode-controls; CSS handles it
}

function setToggleUI(active) {
  $('main-toggle').checked = active;
  $('toggle-label').textContent = active ? 'ON' : 'OFF';
}

function setLinkedUI(linked) {
  $('line-color').disabled = linked;
  $('link-label').classList.toggle('linked', linked);
  $('underline-row').style.opacity = linked ? '0.5' : '1';
}

function flashAutoBadge() {
  const b = $('auto-badge');
  b.classList.add('visible');
  setTimeout(() => b.classList.remove('visible'), 2500);
}

// ─── Main toggle ──────────────────────────────────────────────────────────────
$('main-toggle').addEventListener('change', async () => {
  const res = await sendToTab({ type: 'TOGGLE_OVERLAY' });
  if (res) {
    setToggleUI(res.active);
    if (res.active) {
      if (res.stripHeight) {
        $('strip-height').value = res.stripHeight;
        $('strip-height-val').textContent = res.stripHeight + 'px';
        flashAutoBadge();
      }
      if (res.step) {
        $('step').value = res.step;
        $('step-val').textContent = res.step + 'px';
      }
      if (res.nativeLineHeight) {
        nativeLineHeight = res.nativeLineHeight;
        // Re-render line height display with correct floor
        $('line-height-val').textContent = fmtLineHeight(parseInt($('line-height-override').value));
      }
      if ($('link-toggle').checked) syncUnderlineSwatch();
    }
  } else {
    setToggleUI($('main-toggle').checked);
  }
});

// ─── Pick mode ────────────────────────────────────────────────────────────────
$('pick-btn').addEventListener('click', async () => {
  await sendToTab({ type: 'ENTER_PICK_MODE' });
  setToggleUI(true);
  window.close();
});

// ─── Link toggle ──────────────────────────────────────────────────────────────
$('link-toggle').addEventListener('change', async () => {
  const linked = $('link-toggle').checked;
  setLinkedUI(linked);
  const res = await sendToTab({ type: 'UPDATE_SETTINGS', settings: { linkedColors: linked } });
  if (res?.underlineColor) $('line-color').value = res.underlineColor;
});

async function syncUnderlineSwatch() {
  const res = await sendToTab({
    type: 'UPDATE_SETTINGS',
    settings: { tintColor: hexToRgbStr($('tint-color').value), linkedColors: true }
  });
  if (res?.underlineColor) $('line-color').value = res.underlineColor;
}

// ─── Font picker ──────────────────────────────────────────────────────────────
document.querySelectorAll('input[name="font"]').forEach(radio => {
  radio.addEventListener('change', () => {
    sendToTab({ type: 'UPDATE_SETTINGS', settings: { fontOverride: radio.value } });
  });
});

// ─── Mouse mode toggle ───────────────────────────────────────────────────────
$('mouse-mode-toggle').addEventListener('change', () => {
  const isMouseMode = $('mouse-mode-toggle').checked;
  setMouseModeUI(isMouseMode);
  sendToTab({ type: 'UPDATE_SETTINGS', settings: { mouseMode: isMouseMode } });
});

// ─── Scroll sensor ────────────────────────────────────────────────────────────
$('sensor-toggle').addEventListener('change', () => {
  sendToTab({ type: 'UPDATE_SETTINGS', settings: { mouseSensor: $('sensor-toggle').checked } });
});

document.querySelectorAll('input[name="sensor-side"]').forEach(radio => {
  radio.addEventListener('change', () => {
    sendToTab({ type: 'UPDATE_SETTINGS', settings: { mouseSensorSide: radio.value } });
  });
});

// ─── Scroll mode ──────────────────────────────────────────────────────────────
document.querySelectorAll('input[name="scroll-mode"]').forEach(radio => {
  radio.addEventListener('change', () => {
    sendToTab({ type: 'UPDATE_SETTINGS', settings: { scrollMode: radio.value } });
  });
});

// ─── All slider / color changes ───────────────────────────────────────────────
async function onSettingChange(changedId) {
  // Update display values
  $('opacity-val').textContent            = fmtOpacityPct(parseInt($('opacity').value));
  $('strip-height-val').textContent       = $('strip-height').value + 'px';
  $('mouse-strip-height-val').textContent = $('mouse-strip-height').value + 'px';
  $('step-val').textContent               = $('step').value + 'px';

  $('letter-spacing-val').textContent     = fmtLetterSpacing(parseInt($('letter-spacing').value));
  $('line-height-val').textContent        = fmtLineHeight(parseInt($('line-height-override').value));
  $('column-width-val').textContent       = fmtColumnWidth(parseInt($('column-width').value));

  const scrollMode = document.querySelector('input[name="scroll-mode"]:checked')?.value || 'center';

  // Use whichever strip-height slider was most recently changed.
  // In mouse mode the mouse-strip-height slider is the authoritative one.
  const activeStripHeight = parseInt(
    $('mouse-mode-toggle').checked
      ? $('mouse-strip-height').value
      : $('strip-height').value
  );
  const settings = {
    tintOpacity:        sliderToOpacity(parseInt($('opacity').value)),
    stripHeight:        activeStripHeight,
    step:               parseInt($('step').value),
    tintColor:          hexToRgbStr($('tint-color').value),
    underlineColor:     $('line-color').value,
    linkedColors:       $('link-toggle').checked,
    scrollMode,
    letterSpacing:      parseInt($('letter-spacing').value),
    lineHeightOverride: parseInt($('line-height-override').value),
    columnWidth:        parseInt($('column-width').value),
  };

  const res = await sendToTab({ type: 'UPDATE_SETTINGS', settings });

  if (changedId === 'tint-color' && $('link-toggle').checked && res?.underlineColor) {
    $('line-color').value = res.underlineColor;
  }
}

['opacity','strip-height','mouse-strip-height','step','tint-color','line-color',
 'letter-spacing','line-height-override','column-width'
].forEach(id => {
  $(id).addEventListener('input', () => onSettingChange(id));
});

// ─── Live metrics updates from content script ────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'METRICS_UPDATE') {
    if (msg.stripHeight && !msg.stripHeightManual) {
      $('strip-height').value = msg.stripHeight;
      $('strip-height-val').textContent = msg.stripHeight + 'px';
      $('mouse-strip-height').value = msg.stripHeight;
      $('mouse-strip-height-val').textContent = msg.stripHeight + 'px';
      // Only flash AUTO badge on explicit detection (toggle-on, reset button),
      // not on every line navigation update.
      if (msg.flashBadge) flashAutoBadge();
    }
    if (msg.step && !msg.stepManual) {
      $('step').value = msg.step;
      $('step-val').textContent = msg.step + 'px';
    }
  }
});

// ─── Shading toggle ─────────────────────────────────────────────────────────
$('shading-toggle').addEventListener('change', () => {
  const enabled = $('shading-toggle').checked;
  setShadingControlsUI(enabled);
  sendToTab({ type: 'UPDATE_SETTINGS', settings: { shadingEnabled: enabled } });
});

$('shade-color').addEventListener('input', () => {
  sendToTab({ type: 'UPDATE_SETTINGS', settings: {
    shadeColor: hexToRgbStr($('shade-color').value)
  }});
});

$('shade-opacity').addEventListener('input', () => {
  const pct = parseInt($('shade-opacity').value);
  $('shade-opacity-val').textContent = pct + '%';
  sendToTab({ type: 'UPDATE_SETTINGS', settings: { shadeOpacity: pct / 100 } });
});


// ─── Strip height reset ──────────────────────────────────────────────────────
const stripHeightReset = $('strip-height-reset');
if (stripHeightReset) {
  stripHeightReset.addEventListener('click', async () => {
    await sendToTab({ type: 'UPDATE_SETTINGS', settings: { stripHeightManual: false } });
    const res = await sendToTab({ type: 'DETECT_METRICS' });
    if (res?.stripHeight) {
      $('strip-height').value = res.stripHeight;
      $('strip-height-val').textContent = res.stripHeight + 'px';
      $('mouse-strip-height').value = res.stripHeight;
      $('mouse-strip-height-val').textContent = res.stripHeight + 'px';
      if (res.lineHeight) {
        $('step').value = res.lineHeight;
        $('step-val').textContent = res.lineHeight + 'px';
      }
      flashAutoBadge();
    }
  });
}

// ─── Mouse strip height reset ─────────────────────────────────────────────────
const mouseStripHeightReset = $('mouse-strip-height-reset');
if (mouseStripHeightReset) {
  mouseStripHeightReset.addEventListener('click', async () => {
    await sendToTab({ type: 'UPDATE_SETTINGS', settings: { stripHeightManual: false } });
    const res = await sendToTab({ type: 'DETECT_METRICS' });
    if (res?.stripHeight) {
      $('strip-height').value = res.stripHeight;
      $('strip-height-val').textContent = res.stripHeight + 'px';
      $('mouse-strip-height').value = res.stripHeight;
      $('mouse-strip-height-val').textContent = res.stripHeight + 'px';
      flashAutoBadge();
    }
  });
}

// ─── Strip tint ──────────────────────────────────────────────────────────────
$('strip-tint-toggle').addEventListener('change', () => {
  const enabled = $('strip-tint-toggle').checked;
  setStripTintControlsUI(enabled);
  sendToTab({ type: 'UPDATE_SETTINGS', settings: { stripTintEnabled: enabled } });
});

$('strip-tint-color').addEventListener('input', () => {
  sendToTab({ type: 'UPDATE_SETTINGS', settings: {
    stripTintColor: hexToRgbStr($('strip-tint-color').value)
  }});
});

$('strip-tint-opacity').addEventListener('input', () => {
  const opacity = sliderToOpacity(parseInt($('strip-tint-opacity').value));
  $('strip-tint-opacity-val').textContent = Math.round(opacity * 100) + '%';
  sendToTab({ type: 'UPDATE_SETTINGS', settings: { stripTintOpacity: opacity } });
});

// chrome:// URLs can't be opened via normal anchor clicks in extension popups
const shortcutsLink = $('shortcuts-link');
if (shortcutsLink) {
  shortcutsLink.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: 'chrome://extensions/shortcuts' });
  });
}