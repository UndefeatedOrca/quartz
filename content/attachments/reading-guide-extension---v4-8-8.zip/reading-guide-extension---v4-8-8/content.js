(() => {
  // ═══════════════════════════════════════════════════════════════════════════
  // STATE
  // lineY is ALWAYS viewport-relative px (matches position:fixed).
  // ═══════════════════════════════════════════════════════════════════════════
  let state = {
    active: false,
    pickMode: false,
    lineY: 200,
    stripHeight: 40,
    stripHeightManual: false,
    step: 28,             // used only as px fallback if no lock target
    tintColor: '30, 100, 200',
    tintOpacity: 0.12,
    underlineColor: '#1a4fa0',
    underlineWidth: 2,
    linkedColors: true,
    scrollZone: 20,       // fixed 20% — not user-configurable
    scrollMode: 'center',
    fontOverride: 'off',
    letterSpacing: 0,
    lineHeightOverride: 0,
    mouseMode: false,     // true = line follows mouse, click to lock
    mouseLocked: false,   // true = mouse mode but line is locked in place
    stripTintEnabled: false,
    stripTintColor: '255, 200, 0',  // warm yellow default
    stripTintOpacity: 0.15,
    shadingEnabled: false,
    shadeColor: '30, 100, 200',  // RGB string matching tintColor default
    shadeOpacity: 0.06,
    nativeLineHeight: 0,  // unitless ratio detected on activation; 0 = unknown
    columnWidth: 0,       // max-width in ch units; 0 = off
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // LOCK STATE  — tracks which DOM line we're on
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // A "line record" represents one visual line and is one of two kinds:
  //   { kind:'block', el }          — entire single-line block element
  //   { kind:'wrap', el, lineIdx }  — one wrapped visual line inside a block
  //
  // allLines is the flat ordered list rebuilt on activation.
  // lockedLine is the current position in that list.
  //
  let allLines = [];      // Array of line records
  let lockedLine = null;  // Current line record | null
  let scrollRafId = null;

  // ═══════════════════════════════════════════════════════════════════════════
  // ELEMENTS
  // ═══════════════════════════════════════════════════════════════════════════
  let topTint, strip, bottomTint, pickCursor, pickBanner, container, captureLayer;

  // ═══════════════════════════════════════════════════════════════════════════
  // COLOR UTILITIES
  // ═══════════════════════════════════════════════════════════════════════════
  function parseRGB(str) { return str.split(',').map(n => parseInt(n.trim())); }

  function rgbToHex([r, g, b]) {
    return '#' + [r,g,b].map(n =>
      Math.max(0,Math.min(255,Math.round(n))).toString(16).padStart(2,'0')
    ).join('');
  }

  function deriveUnderlineColor(rgbStr) {
    const [r,g,b] = parseRGB(rgbStr);
    const max = Math.max(r,g,b) || 1;
    const scale = (200/max) * 0.7;
    return rgbToHex([r*scale, g*scale, b*scale]);
  }


  // ═══════════════════════════════════════════════════════════════════════════
  // FONT & TYPOGRAPHY INJECTION
  // ═══════════════════════════════════════════════════════════════════════════

  // Map fontOverride keys → CSS font-family stacks
  // Local fonts use chrome.runtime.getURL so the extension can serve them
  function getFontFaceCSS(key) {
    if (key === 'off') return '';
    const base = chrome.runtime.getURL('fonts/');

    const faceBlocks = {
      atkinson: `
        @font-face { font-family: '__RG_Atkinson'; font-weight: 400; font-style: normal;
          src: url('${base}AtkinsonHyperlegible-Regular.ttf') format('truetype'); }
        @font-face { font-family: '__RG_Atkinson'; font-weight: 700; font-style: normal;
          src: url('${base}AtkinsonHyperlegible-Bold.ttf') format('truetype'); }
        @font-face { font-family: '__RG_Atkinson'; font-weight: 400; font-style: italic;
          src: url('${base}AtkinsonHyperlegible-Italic.ttf') format('truetype'); }
        @font-face { font-family: '__RG_Atkinson'; font-weight: 700; font-style: italic;
          src: url('${base}AtkinsonHyperlegible-BoldItalic.ttf') format('truetype'); }`,
      opendyslexic: `
        @font-face { font-family: '__RG_OpenDyslexic'; font-weight: 400; font-style: normal;
          src: url('${base}OpenDyslexic-Regular.otf') format('opentype'); }
        @font-face { font-family: '__RG_OpenDyslexic'; font-weight: 700; font-style: normal;
          src: url('${base}OpenDyslexic-Bold.otf') format('opentype'); }
        @font-face { font-family: '__RG_OpenDyslexic'; font-weight: 400; font-style: italic;
          src: url('${base}OpenDyslexic-Italic.otf') format('opentype'); }
        @font-face { font-family: '__RG_OpenDyslexic'; font-weight: 700; font-style: italic;
          src: url('${base}OpenDyslexic-BoldItalic.otf') format('opentype'); }`,
      lexend: `
        @font-face { font-family: '__RG_Lexend'; font-weight: 100 900; font-style: normal;
          src: url('${base}Lexend-VariableFont_wght.ttf') format('truetype'); }`,
    };

    const fontFamily = {
      atkinson:     "'__RG_Atkinson', sans-serif",
      opendyslexic: "'__RG_OpenDyslexic', sans-serif",
      lexend:       "'__RG_Lexend', sans-serif",
      'comic-sans': "'Comic Sans MS', 'Comic Sans', cursive",
      verdana:      "Verdana, Geneva, sans-serif",
    }[key];

    if (!fontFamily) return '';

    // Use high-specificity selector to beat site !important declarations.
    // Icon fonts are protected by excluding common icon class patterns.
    const iconExclusion = [
      ':not([class*="fa-"])',
      ':not([class*="icon-"])',
      ':not([class*="glyphicon"])',
      ':not([class*="material-icon"])',
      ':not([class*="bi-"])',
    ].join('');

    // html body * gives 3 element selectors — beats most site rules without
    // needing ID selectors, and still loses to inline styles (intentional).
    return `
      ${faceBlocks[key] || ''}
      html body *${iconExclusion} {
        font-family: ${fontFamily} !important;
      }
    `;
  }

  // Returns document.head if it exists, otherwise appends one.
  // Some pages (e.g. plain XML, minimal HTML) may lack <head> at script run time.
  function getOrCreateHead() {
    if (document.head) return document.head;
    const head = document.createElement('head');
    const ref = document.body || document.documentElement.firstChild || null;
    document.documentElement.insertBefore(head, ref);
    return head;
  }

  // Style elements are created once and reused. If the page navigates away and
  // they get removed from the DOM, re-append them.
  let fontStyleEl  = null;
  let typoStyleEl  = null;
  let shadeStyleEl  = null;
  let columnStyleEl = null;

  function ensureStyleEl(id, ref) {
    // Re-use existing element if still in the document
    if (ref && document.getElementById(id)) return ref;
    // Otherwise create fresh
    const el = document.createElement('style');
    el.id = id;
    getOrCreateHead().appendChild(el);
    return el;
  }

  function applyFontOverride() {
    fontStyleEl = ensureStyleEl('__reading-guide-font__', fontStyleEl);
    fontStyleEl.textContent = getFontFaceCSS(state.fontOverride);

    typoStyleEl = ensureStyleEl('__reading-guide-typo__', typoStyleEl);

    const rules = [];
    if (state.letterSpacing > 0) {
      rules.push(`letter-spacing: ${(state.letterSpacing / 100).toFixed(2)}em !important;`);
    }
    if (state.lineHeightOverride > 0) {
      // Floor at native line height (detected on activation) so the slider
      // always increases from where the page was, never decreases it.
      const floor = state.nativeLineHeight > 0 ? state.nativeLineHeight : 1.5;
      const lh = (floor + state.lineHeightOverride * 0.1).toFixed(2);
      rules.push(`line-height: ${lh} !important;`);
    }
    typoStyleEl.textContent = rules.length > 0
      ? `html body, html body * { ${rules.join(' ')} }`
      : '';

    // After font change, give browser time to render then re-detect metrics
    // and rebuild. Font loading is async so we wait for the font face to be
    // ready if possible, with a 600ms hard fallback.
    if (state.active) {
      const doRebuild = () => {
        const metrics = detectLineMetrics();
        if (!state.stripHeightManual) state.stripHeight = metrics.stripHeight;
        state.step = metrics.lineHeight;
        if (metrics.nativeLineHeight > 0) state.nativeLineHeight = metrics.nativeLineHeight;
        allBlocksCache = null;
        lastWindowScrollY = -Infinity;
        rebuildWindow();
        lockedLine = nearestLine(state.lineY + state.stripHeight / 2);
        render();
        saveState();
        // Tell popup to update the strip height slider
        if (!state.stripHeightManual) {
          chrome.runtime.sendMessage({
            type: 'METRICS_UPDATE',
            stripHeight: state.stripHeight,
            stripHeightManual: false,
            step: state.step,
            flashBadge: true,
          }).catch(() => {});
        }
      };
      // document.fonts.ready resolves once all pending font loads complete
      if (state.fontOverride !== 'off' && document.fonts?.ready) {
        Promise.race([
          document.fonts.ready,
          new Promise(r => setTimeout(r, 600)),
        ]).then(doRebuild);
      } else {
        setTimeout(doRebuild, 100);
      }
    }
  }


  function applyShading() {
    shadeStyleEl = ensureStyleEl('__reading-guide-shade__', shadeStyleEl);
    if (!state.shadingEnabled) {
      shadeStyleEl.textContent = '';
      return;
    }
    const c = state.shadeColor;
    const o = state.shadeOpacity;
    const bg = `rgba(${c}, ${o})`;
    // nth-of-type counts only among siblings of the same tag, giving true
    // alternation regardless of intervening divs, images, headings etc.
    // nth-child counts all siblings so most paragraphs end up odd on typical
    // article pages where every <p> is a direct child.
    const selectors = 'p:nth-of-type(odd), li:nth-of-type(odd)';
    shadeStyleEl.textContent = `
      ${selectors} {
        background-color: ${bg};
      }
      header ${selectors}, nav ${selectors}, footer ${selectors},
      aside ${selectors}, [role="banner"] ${selectors},
      [role="navigation"] ${selectors}, [role="contentinfo"] ${selectors} {
        background-color: transparent;
      }
    `;
  }

  function applyColumnWidth() {
    columnStyleEl = ensureStyleEl('__reading-guide-column__', columnStyleEl);
    if (!state.columnWidth) {
      columnStyleEl.textContent = '';
      return;
    }
    // Target viewport percentage: steps 1–9 → 40%–80% in 5% increments.
    // Apply max-width + margin: auto directly to <body> — it's always the same
    // element, always the layout root, and margin:auto centering is universally
    // reliable. This avoids the container-detection and padding-accumulation
    // problems that plagued the previous approach.
    const vwPct = 35 + state.columnWidth * 5;
    const targetPx = Math.round(window.innerWidth * vwPct / 100);
    columnStyleEl.textContent = `
      body {
        max-width: ${targetPx}px !important;
        margin-left: auto !important;
        margin-right: auto !important;
        box-sizing: border-box !important;
      }
    `;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // METRICS DETECTION
  // ═══════════════════════════════════════════════════════════════════════════
  const SKIP_TAGS  = new Set(['HEADER','NAV','ASIDE','FOOTER','SCRIPT','STYLE','NOSCRIPT']);
  const SKIP_ROLES = new Set(['banner','navigation','complementary','contentinfo']);

  function isInChrome(el) {
    let p = el;
    while (p && p !== document.body) {
      if (SKIP_TAGS.has(p.tagName)) return true;
      if (p.getAttribute && SKIP_ROLES.has(p.getAttribute('role'))) return true;
      p = p.parentElement;
    }
    return false;
  }

  function detectLineMetrics() {
    const allCandidates = Array.from(
      document.querySelectorAll('p, li, td, blockquote')
    ).filter(el => !isInChrome(el) && (el.innerText?.trim().length || 0) > 60);

    // Prefer body-text-sized elements over headings/heroes.
    // Compute median font size among candidates and exclude anything >20% larger.
    let el = document.body;
    if (allCandidates.length) {
      const sizes = allCandidates.map(e => parseFloat(getComputedStyle(e).fontSize) || 16);
      sizes.sort((a, b) => a - b);
      const medianSize = sizes[Math.floor(sizes.length / 2)];
      const bodyText = allCandidates.filter(e => {
        const fs = parseFloat(getComputedStyle(e).fontSize) || 16;
        return fs <= medianSize * 1.2;
      });
      // Prefer an element with multiple rendered lines so we can measure real gaps
      el = bodyText.find(e => {
        const r = getTextOnlyRects(e);
        return r && r.length >= 4;
      }) || bodyText[0] || allCandidates[0] || document.body;
    }

    // Measure actual rendered line height from text rects — this reflects the
    // active font (including overrides) rather than the CSS line-height value,
    // which doesn't update when a different font with a larger em-square loads.
    const rects = getTextOnlyRects(el);
    let lh = 0;
    if (rects && rects.length >= 2) {
      // Collect distinct line tops and measure the median gap between them
      const tops = [];
      for (const r of rects) {
        if (tops.length === 0 || Math.abs(r.top - tops[tops.length - 1]) > 4) {
          tops.push(r.top);
        }
      }
      if (tops.length >= 2) {
        const gaps = [];
        for (let i = 1; i < tops.length; i++) gaps.push(tops[i] - tops[i-1]);
        gaps.sort((a, b) => a - b);
        lh = Math.round(gaps[Math.floor(gaps.length / 2)]);
      }
    }

    // Fallback to CSS line-height if we couldn't measure from rects
    if (!lh || lh < 10) {
      const cs = window.getComputedStyle(el);
      lh = parseFloat(cs.lineHeight);
      if (isNaN(lh)) lh = (parseFloat(cs.fontSize)||16) * 1.4;
      lh = Math.round(lh);
    }

    // Also capture the native unitless line-height ratio from the candidate
    // element so the popup can use it as the floor for the line height slider.
    let nativeLHRatio = 0;
    {
      const cs = window.getComputedStyle(el);
      const fs = parseFloat(cs.fontSize) || 16;
      const cssLH = parseFloat(cs.lineHeight);
      if (!isNaN(cssLH) && fs > 0) {
        nativeLHRatio = Math.round((cssLH / fs) * 10) / 10; // 1 decimal place
      } else {
        nativeLHRatio = Math.round((lh / fs) * 10) / 10;
      }
    }
    return { lineHeight: lh, stripHeight: lh + 6, nativeLineHeight: nativeLHRatio };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // LINE LIST — windowed indexing
  // ═══════════════════════════════════════════════════════════════════════════
  //
  // On large documents (Project Gutenberg, long articles) indexing the entire
  // page synchronously is too expensive and hits MAX_TOTAL_LINES far short of
  // where the user is reading. Instead we index a WINDOW: elements within
  // WINDOW_VH viewport-heights above and below the current viewport, rebuilding
  // the window on scroll and on navigation keypresses.
  //
  // allLines always covers the window. Indices are stable within a window;
  // when the window shifts we remap lockedLine by DOM identity.

  const BLOCK_SEL = [
    'p', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'tr',                           // whole row = one navigation unit
    'blockquote', 'dt', 'dd', 'figcaption', 'caption',
    'div', 'pre',
  ].join(', ');

  const MAX_LINES_PER_BLOCK = 40;
  const WINDOW_VH = 5; // index elements within ±5 viewport-heights of current scroll

  // Extract only TEXT-bearing rects from an element, filtering out image rects.
  function getTextOnlyRects(el) {
    try {
      if (!el || !document.body || !document.body.contains(el)) return null;
      // For table rows, use the row's own bounding rect rather than walking
      // text nodes across cells — cross-cell rects interleave and produce
      // phantom wrapped lines.
      if (el.tagName === 'TR') {
        const r = el.getBoundingClientRect();
        return r.height > 0 ? [r] : null;
      }
      const rects = [];
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, {
        acceptNode: n => n.textContent.trim() ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP,
      });
      let node;
      while ((node = walker.nextNode())) {
        const range = document.createRange();
        range.selectNodeContents(node);
        for (const r of range.getClientRects()) {
          if (r.width > 2 && r.height > 2) rects.push(r);
        }
      }
      return rects.length > 0 ? rects : null;
    } catch {
      return null;
    }
  }

  function getLineRects(el) {
    const rawRects = getTextOnlyRects(el);
    if (!rawRects) return null;

    // Compute dominant (median) rect height so we can set a sensible merge
    // tolerance. Fractions produce short rects at offset tops; using a fixed
    // 4px tolerance splits them into phantom lines.
    const heights = rawRects.map(r => r.height).sort((a, b) => a - b);
    const medianH = heights[Math.floor(heights.length / 2)] || 16;
    // Merge tolerance: rects within 60% of the median line height are on the
    // same visual line. This handles fractions (offset ~8-12px) while still
    // splitting genuinely separate lines (offset > 1 line-height).
    const tolerance = medianH * 0.6;

    const lines = [];
    for (const r of rawRects) {
      const last = lines[lines.length - 1];
      if (last && Math.abs(r.top - last.top) < tolerance) {
        last.height = Math.max(last.height, r.height);
        // Keep the top of the earliest rect (closest to true baseline)
        last.top = Math.min(last.top, r.top);
      } else {
        if (lines.length >= MAX_LINES_PER_BLOCK) break;
        lines.push({ top: r.top, height: r.height });
      }
    }
    return lines.length > 0 ? lines : null;
  }

  // Return all candidate block elements whose bounding rect overlaps
  // the given document-absolute y range [minY, maxY].
  // Uses getBoundingClientRect + scrollY so we work in document coords.
  function getBlocksInRange(minDocY, maxDocY) {
    const all = Array.from(document.querySelectorAll(BLOCK_SEL));
    const result = [];
    // Compute the horizontal band that contains most of the text content.
    // We do a fast first pass to find the modal center-x of visible text
    // elements, then use it to exclude sidebars in the main pass.
    // Only computed when there are enough candidates to be meaningful.
    let contentCenterX = null;
    if (all.length > 6) {
      const xs = [];
      for (const el of all) {
        if (isInChrome(el)) continue;
        const r = el.getBoundingClientRect();
        if (r.width > 50 && r.height > 0) xs.push(r.left + r.width / 2);
        if (xs.length >= 40) break; // sample enough, don't scan everything
      }
      if (xs.length > 4) {
        xs.sort((a, b) => a - b);
        contentCenterX = xs[Math.floor(xs.length / 2)]; // median center-x
      }
    }

    for (const el of all) {
      if (isInChrome(el)) continue;
      if (el.tagName === 'DIV' || el.tagName === 'PRE') {
        if (el.querySelector('p, li, h1, h2, h3, h4, h5, h6, blockquote, td')) continue;
      }
      // Skip tr elements that contain nested tables or block children —
      // those will be indexed as their own blocks.
      if (el.tagName === 'TR') {
        if (el.querySelector('table, p, li, ul, ol, h1, h2, h3, h4, h5, h6')) continue;
      }
      const text = el.innerText?.trim() || '';
      if (text.length === 0) continue;
      const r = el.getBoundingClientRect();
      if (r.height === 0 || r.width === 0) continue;
      // Skip elements hidden via visibility or opacity (catches SEO duplicates
      // and off-screen pre-render copies that have non-zero dimensions).
      const cs = getComputedStyle(el);
      if (cs.visibility === 'hidden' || cs.opacity === '0') continue;
      // Skip elements horizontally outside the main content band.
      // Tolerance scales with viewport width so wide layouts (e.g. sites with
      // margin sidenotes) don't have their main text column excluded when the
      // sidenotes pull the median center-x away from the text column.
      if (contentCenterX !== null) {
        const elCenterX = r.left + r.width / 2;
        const tolerancePx = Math.round(window.innerWidth * 0.35);
        if (Math.abs(elCenterX - contentCenterX) > tolerancePx) continue;
      }
      const elDocTop = r.top + window.scrollY;
      const elDocBot = r.bottom + window.scrollY;
      if (elDocBot < minDocY || elDocTop > maxDocY) continue;
      result.push(el);
    }
    return result;
  }

  // Build line records from a set of block elements.
  function buildLinesFromBlocks(blocks) {
    const lines = [];
    for (const el of blocks) {
      const lineRects = getLineRects(el);
      if (!lineRects || lineRects.length <= 1) {
        lines.push({ kind: 'block', el });
      } else {
        lineRects.forEach((_, idx) => lines.push({ kind: 'wrap', el, lineIdx: idx }));
      }
    }
    return lines;
  }

  // Rebuild allLines for the window around the current scroll position.
  // lockedLine is NOT remapped here — it's a stable DOM reference that
  // exists independently of allLines.
  function rebuildWindow() {
    const vh = window.innerHeight;
    const scrollY = window.scrollY;
    const minDocY = scrollY - WINDOW_VH * vh;
    const maxDocY = scrollY + (WINDOW_VH + 1) * vh;

    const blocks = getBlocksInRange(minDocY, maxDocY);
    allLines = buildLinesFromBlocks(blocks);
  }

  // Throttled window rebuild on scroll — only rebuild if scroll moved
  // more than half a viewport from the last build position.
  let lastWindowScrollY = -Infinity;
  function maybeRebuildWindow() {
    if (Math.abs(window.scrollY - lastWindowScrollY) > window.innerHeight * 0.5) {
      lastWindowScrollY = window.scrollY;
      rebuildWindow();
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // LOCK HELPERS — map a line record to a viewport Y
  // ═══════════════════════════════════════════════════════════════════════════
  // Measure the rendered pixel height of a line record.
  // For block kind: element's bounding rect height (capped at 3× step to avoid
  // single-line blocks whose rect includes padding).
  // For wrap kind: the rect height of that specific visual line.
  function getLineHeight(lineRecord) {
    if (!lineRecord) return state.step;
    if (lineRecord.kind === 'wrap') {
      const lineRects = getLineRects(lineRecord.el);
      if (lineRects && lineRects[lineRecord.lineIdx] !== undefined) {
        return Math.round(lineRects[lineRecord.lineIdx].height);
      }
    }
    // block kind — use computed line-height, not element height
    const cs = window.getComputedStyle(lineRecord.el);
    const lh = parseFloat(cs.lineHeight);
    if (!isNaN(lh) && lh > 0) return Math.round(lh);
    return state.step;
  }

  function getLineTop(lineRecord) {
    if (!lineRecord) return state.lineY;

    if (lineRecord.kind === 'block') {
      const r = lineRecord.el.getBoundingClientRect();
      return r.top;
    }

    // wrap kind — re-read line rects
    const lineRects = getLineRects(lineRecord.el);
    if (lineRects && lineRects[lineRecord.lineIdx] !== undefined) {
      return lineRects[lineRecord.lineIdx].top;
    }
    // fallback: element top + lineIdx * lineHeight
    const r = lineRecord.el.getBoundingClientRect();
    return r.top + lineRecord.lineIdx * state.step;
  }

  function lockToLine(lineRecord) {
    lockedLine = lineRecord;
    if (!lineRecord) return;
    const top = getLineTop(lineRecord);
    state.lineY = Math.max(0, top - 2); // 2px above the text baseline
    // Update strip height to match this specific line, unless user has
    // manually overridden it.
    if (!state.stripHeightManual) {
      const lh = getLineHeight(lineRecord);
      if (lh > 0) {
        const newHeight = lh + 6; // 3px padding top and bottom
        if (newHeight !== state.stripHeight) {
          state.stripHeight = newHeight;
          // Notify popup to update slider (no badge flash — this is automatic)
          chrome.runtime.sendMessage({
            type: 'METRICS_UPDATE',
            stripHeight: state.stripHeight,
            stripHeightManual: false,
          }).catch(() => {});
        }
      }
    }
    render();
  }

  // Find the line record whose top is nearest to a viewport Y
  function nearestLine(viewportY) {
    if (allLines.length === 0) return null;
    let best = null, bestDist = Infinity;
    for (const ln of allLines) {
      const top = getLineTop(ln);
      const dist = Math.abs(top - viewportY);
      if (dist < bestDist) { bestDist = dist; best = ln; }
    }
    return best;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SCROLL LISTENER — re-anchor overlay to locked line, rebuild window as needed
  // ═══════════════════════════════════════════════════════════════════════════
  function onScroll() {
    if (!state.active) return;
    if (suppressScrollLock) return;
    // In mouse mode the line is positioned relative to the viewport, not the
    // document — scrolling doesn't move it. Only rebuild window for pick mode
    // line snapping; don't re-anchor lineY.
    if (state.mouseMode) {
      maybeRebuildWindow();
      return;
    }

    maybeRebuildWindow();

    // In fixed mode the line is viewport-pinned — it never moves on scroll,
    // only on arrow keypresses. The page scrolls under the line.
    if (state.scrollMode === 'fixed') return;

    if (!lockedLine) return;
    if (scrollRafId) return;
    scrollRafId = requestAnimationFrame(() => {
      scrollRafId = null;
      const top = getLineTop(lockedLine);
      // Only update lineY if the element is actually near the viewport.
      // If it's far off-screen (user jumped with browser scrollbar), let it go
      // and wait for the next arrow keypress to re-lock.
      const nearViewport = top > -window.innerHeight * 2 && top < window.innerHeight * 3;
      if (nearViewport) {
        state.lineY = Math.max(0, top - 2);
        render();
      } else {
        // Element scrolled far away — snap to nearest visible line rather than
        // losing the bar entirely. This recovers gracefully from infinite scroll
        // jumps and browser scrollbar navigation.
        rebuildWindow();
        const snap = nearestLine(state.lineY + state.stripHeight / 2);
        if (snap) {
          lockedLine = snap;
          state.lineY = Math.max(0, getLineTop(snap) - 2);
          render();
        } else {
          lockedLine = null;
        }
      }
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // MOUSE MODE — line follows cursor, click to lock/unlock
  // ═══════════════════════════════════════════════════════════════════════════
  let mouseMoveRafId = null;

  function onMouseMove(e) {
    if (!state.active || !state.mouseMode || state.mouseLocked || state.pickMode) return;
    if (mouseMoveRafId) return;
    const clientY = e.clientY; // capture before rAF
    mouseMoveRafId = requestAnimationFrame(() => {
      mouseMoveRafId = null;
      state.lineY = Math.max(0,
        Math.min(window.innerHeight - state.stripHeight - 2,
          clientY - state.stripHeight / 2));
      render();
    });
  }

  function onMouseClick(e) {
    if (!state.active || !state.mouseMode || state.pickMode) return;
    if (e.target.closest && e.target.closest('#__reading-guide-container__')) return;
    state.mouseLocked = !state.mouseLocked;
    if (state.mouseLocked) {
      // Re-locking — snap lockedLine to wherever lineY currently is so that
      // subsequent arrow presses and scrolls anchor to the new position,
      // not wherever the line was on the previous lock.
      rebuildWindow();
      const snap = nearestLine(state.lineY + state.stripHeight / 2);
      if (snap) {
        lockedLine = snap;
        state.lineY = Math.max(0, getLineTop(snap) - 2);
        render();
      }
    } else {
      // Unlocking — release the DOM anchor so the line follows the mouse freely
      lockedLine = null;
    }
    saveState();
    if (strip) {
      strip.style.transition = 'opacity 0.1s';
      strip.style.opacity = '0.5';
      setTimeout(() => { strip.style.opacity = '1'; strip.style.transition = ''; }, 150);
    }
  }

  function enterMouseMode() {
    state.mouseMode = true;
    state.mouseLocked = false;
    lockedLine = null;
    // Remove first to avoid duplicate listeners if called multiple times
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('click', onMouseClick);
    document.addEventListener('mousemove', onMouseMove, { passive: true });
    document.addEventListener('click', onMouseClick);
    // Show captureLayer so mouse events are received over PDF embeds and other
    // sandboxed elements that swallow pointer events before they reach document.
    // Use default cursor (not crosshair) so it's invisible to the user.
    if (captureLayer) {
      captureLayer.style.cursor = 'default';
      captureLayer.style.display = 'block';
    }
    render();
  }

  function exitMouseMode() {
    state.mouseMode = false;
    state.mouseLocked = false;
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('click', onMouseClick);
    if (captureLayer) captureLayer.style.display = 'none';
    // Snap to the nearest DOM line at the current lineY so scroll and keypresses
    // work immediately without jumping. Rebuild the window first so allLines is
    // populated at the current scroll position.
    lastWindowScrollY = -Infinity;
    rebuildWindow();
    const snap = nearestLine(state.lineY + state.stripHeight / 2);
    if (snap) {
      lockedLine = snap;
      state.lineY = Math.max(0, getLineTop(snap) - 2);
    }
    render();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // OVERLAY BUILD & RENDER
  // ═══════════════════════════════════════════════════════════════════════════
  function buildOverlay() {
    if (container) return;

    container = document.createElement('div');
    container.id = '__reading-guide-container__';
    Object.assign(container.style, {
      position:'fixed', inset:'0', zIndex:'2147483640', pointerEvents:'none',
    });

    topTint = document.createElement('div');
    Object.assign(topTint.style, {
      position:'fixed', left:'0', right:'0', top:'0', pointerEvents:'none',
    });

    strip = document.createElement('div');
    Object.assign(strip.style, {
      position:'fixed', left:'0', right:'0', pointerEvents:'none', boxSizing:'border-box',
    });

    bottomTint = document.createElement('div');
    Object.assign(bottomTint.style, {
      position:'fixed', left:'0', right:'0', bottom:'0', pointerEvents:'none',
    });

    pickCursor = document.createElement('div');
    Object.assign(pickCursor.style, {
      position:'fixed', left:'0', right:'0', pointerEvents:'none', display:'none',
      borderTop:'2px dashed rgba(59,130,246,0.7)',
      borderBottom:'2px dashed rgba(59,130,246,0.7)',
      background:'rgba(59,130,246,0.08)',
    });

    pickBanner = document.createElement('div');
    Object.assign(pickBanner.style, {
      position:'fixed', top:'12px', left:'50%', transform:'translateX(-50%)',
      zIndex:'2147483647', background:'rgba(15,23,42,0.92)', color:'#e2e8f0',
      fontFamily:'system-ui,sans-serif', fontSize:'13px', fontWeight:'500',
      padding:'8px 18px', borderRadius:'99px', pointerEvents:'none', display:'none',
      backdropFilter:'blur(8px)', border:'1px solid rgba(255,255,255,0.1)',
      letterSpacing:'0.02em', boxShadow:'0 4px 24px rgba(0,0,0,0.4)', whiteSpace:'nowrap',
    });
    pickBanner.textContent = '🎯 Click to place reading line · Esc to cancel';

    container.appendChild(topTint);
    container.appendChild(strip);
    container.appendChild(bottomTint);
    container.appendChild(pickCursor);
    if (!document.body) return;
    document.body.appendChild(container);
    document.body.appendChild(pickBanner);
  }

  function render() {
    if (!state.active) {
      if (container) container.style.display = 'none';
      return;
    }
    buildOverlay();
    container.style.display = '';

    const y = Math.max(0, Math.min(state.lineY, window.innerHeight - state.stripHeight - 2));
    const tint = `rgba(${state.tintColor}, ${state.tintOpacity})`;

    topTint.style.height = `${y}px`;
    topTint.style.background = tint;

    strip.style.top = `${y}px`;
    strip.style.height = `${state.stripHeight}px`;
    strip.style.background = state.stripTintEnabled
      ? `rgba(${state.stripTintColor}, ${state.stripTintOpacity})`
      : 'transparent';
    strip.style.borderBottom = `${state.underlineWidth}px solid ${state.underlineColor}`;

    bottomTint.style.top = `${y + state.stripHeight}px`;
    bottomTint.style.background = tint;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PICK MODE
  // ═══════════════════════════════════════════════════════════════════════════
  function buildCaptureLayer() {
    if (captureLayer) return;
    captureLayer = document.createElement('div');
    Object.assign(captureLayer.style, {
      position:'fixed', inset:'0', zIndex:'2147483645', cursor:'crosshair', display:'none',
    });

    captureLayer.addEventListener('mousemove', (e) => {
      const y = e.clientY - state.stripHeight / 2;
      pickCursor.style.top = `${y}px`;
      pickCursor.style.height = `${state.stripHeight}px`;

      // Highlight nearest line as a hint
      const nearest = nearestLine(e.clientY);
      if (nearest) {
        const top = getLineTop(nearest);
        pickCursor.style.top = `${top - 2}px`;
      }
    });

    captureLayer.addEventListener('click', (e) => {
      if (state.mouseMode) {
        // In mouse mode captureLayer is just a transparent event surface —
        // delegate to the normal mouse click handler.
        onMouseClick(e);
        return;
      }
      if (!state.pickMode) return;
      e.preventDefault();
      e.stopPropagation();
      const nearest = nearestLine(e.clientY);
      exitPickMode();
      if (nearest) {
        lockToLine(nearest);
      } else {
        state.lineY = Math.max(0, e.clientY - state.stripHeight / 2);
        render();
      }
      saveState();
    });

    if (!document.body) return;
    document.body.appendChild(captureLayer);
  }

  function enterPickMode() {
    state.pickMode = true;
    pickBanner.style.display = 'block';
    pickCursor.style.display = 'block';
    captureLayer.style.display = 'block';
  }

  function exitPickMode() {
    state.pickMode = false;
    pickBanner.style.display = 'none';
    pickCursor.style.display = 'none';
    // Keep captureLayer visible if mouse mode is active (it covers PDF embeds)
    if (!state.mouseMode) captureLayer.style.display = 'none';
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // KEYBOARD — true line-by-line DOM navigation
  // ═══════════════════════════════════════════════════════════════════════════

  // scrollPending: index we are navigating TO while scrollIntoView is settling.
  // While set, arrow keys queue up as a pending offset rather than re-deriving
  // position — this prevents the stale-index backward-jump bug.
  let scrollPending = null;       // null | { pendingDelta, timeoutId }
  let suppressScrollLock = false; // true while fixed-mode scrollTo is in flight

  // All candidate block elements in DOM order — used for cross-window navigation.
  // Rebuilt lazily; allBlocks is the source of truth, allLines is the viewport window.
  let allBlocksCache = null;
  let allBlocksCacheTime = 0;

  function getAllBlocks() {
    // Cache for 2s — cheap on normal pages, avoids re-querying 4000 elements per keypress
    if (allBlocksCache && Date.now() - allBlocksCacheTime < 2000) return allBlocksCache;
    allBlocksCache = Array.from(document.querySelectorAll(BLOCK_SEL)).filter(el => {
      if (isInChrome(el)) return false;
      if (el.tagName === 'DIV' || el.tagName === 'PRE') {
        if (el.querySelector('p, li, h1, h2, h3, h4, h5, h6, blockquote, td')) return false;
      }
      if (el.tagName === 'TR' && el.querySelector('table, p, li, ul, ol, h1, h2, h3, h4, h5, h6')) return false;
      return (el.innerText?.trim().length || 0) > 0;
    });
    allBlocksCacheTime = Date.now();
    return allBlocksCache;
  }

  // Navigate to the next/previous visual line.
  // Within a multi-line block: step lineIdx.
  // At block boundary: move to next/prev block in DOM order.
  function navigateLine(dir) {
    if (!lockedLine) {
      // No lock — find nearest visible line and lock to it without stepping
      rebuildWindow();
      const nearest = nearestLine(state.lineY + state.stripHeight / 2);
      if (nearest) lockToLine(nearest);
      return;
    }

    const { el, kind, lineIdx = 0 } = lockedLine;

    if (kind === 'wrap') {
      // Try stepping within current block first
      const lineRects = getLineRects(el);
      const maxIdx = lineRects ? lineRects.length - 1 : 0;
      const nextIdx = lineIdx + dir;
      if (nextIdx >= 0 && nextIdx <= maxIdx) {
        const newLine = { kind: 'wrap', el, lineIdx: nextIdx };
        scrollIntoViewIfNeeded(newLine, dir);
        return;
      }
      // Fell off the end of this block — fall through to block navigation
    }

    // Move to next/prev block in full DOM order
    const blocks = getAllBlocks();
    const elIdx = blocks.indexOf(el);
    if (elIdx === -1) {
      // Element not in cache (rare) — invalidate and use nearest
      allBlocksCache = null;
      rebuildWindow();
      const nearest = nearestLine(state.lineY + state.stripHeight / 2);
      if (nearest) lockToLine(nearest);
      return;
    }

    const currentTop = getLineTop(lockedLine);
    let nextElIdx = elIdx + dir;

    while (true) {
      if (nextElIdx < 0 || nextElIdx >= blocks.length) return; // at document edge

      const nextEl = blocks[nextElIdx];
      const lineRects = getLineRects(nextEl);
      let newLine;
      if (!lineRects || lineRects.length <= 1) {
        newLine = { kind: 'block', el: nextEl };
      } else {
        // Enter from the correct end of the block
        const targetLineIdx = dir === 1 ? 0 : lineRects.length - 1;
        newLine = { kind: 'wrap', el: nextEl, lineIdx: targetLineIdx };
      }

      // Skip elements that don't advance in the pressed direction.
      // This handles multi-column layouts and floats where DOM order doesn't
      // match visual order — if pressing ↓ would land us at the same or higher
      // Y position, keep searching further in the same direction.
      const newTop = getLineTop(newLine);
      const delta = newTop - currentTop;
      if (dir === 1 ? delta > 0 : delta < 0) {
        scrollIntoViewIfNeeded(newLine, dir);
        return;
      }

      nextElIdx += dir;
    }
  }

  // Lock to a line, scrolling the page if needed.
  function scrollIntoViewIfNeeded(newLine, dir) {
    lockedLine = newLine;
    const top = getLineTop(newLine);

    if (state.scrollMode === 'fixed') {
      // Fixed mode: always scroll the page to bring the target element to
      // lineY. The line never moves — the page moves under it.
      // Skip the zone check entirely; every keypress scrolls to keep the
      // line exactly on the target element.
      {
      // We want the element to appear at state.lineY in the viewport.
      // Compute the exact document scrollTop that achieves this:
      //   element's document-absolute top = top + window.scrollY
      //   desired viewport top of element = state.lineY
      //   therefore: scrollTop = (top + scrollY) - lineY
      const targetScrollTop = (top + window.scrollY) - state.lineY;
      suppressScrollLock = true;
      window.scrollTo({ top: targetScrollTop, behavior: 'instant' });
      // Double-rAF: first frame commits the scroll, second reads settled layout.
      requestAnimationFrame(() => requestAnimationFrame(() => {
        suppressScrollLock = false;
        lockedLine = newLine;
        // lineY is the fixed viewport anchor — never change it on keypress.
        // lockToLine would update lineY; call render directly instead.
        if (!state.stripHeightManual) {
          const lh = getLineHeight(newLine);
          if (lh > 0) state.stripHeight = lh + 6;
        }
        render();
        saveState();
      }));
      return;
      }
    }

    // Center mode: only scroll if outside the scroll zone
    const zonePx = Math.round(window.innerHeight * (state.scrollZone / 100));
    const offTop    = top < zonePx;
    const offBottom = top > window.innerHeight - zonePx - state.stripHeight;
    if (!offTop && !offBottom) {
      lockToLine(newLine);
      saveState();
      return;
    }
    {
      if (scrollPending) {
        clearTimeout(scrollPending.timeoutId);
        scrollPending = null;
      }
      // Guard against runaway scroll on infinite-scroll pages (Twitter etc).
      // If the target is more than 2 viewport heights away it's likely a
      // just-rendered lazy element — lock in place rather than chasing it.
      const docTop = newLine.el.getBoundingClientRect().top + window.scrollY;
      const currentCenter = window.scrollY + window.innerHeight / 2;
      if (Math.abs(docTop - currentCenter) > window.innerHeight * 2) {
        lockToLine(newLine);
        saveState();
        return;
      }
      newLine.el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      // Detect scroll end by watching for scrollY to stop changing.
      // Check every 50ms; if scrollY hasn't moved in two consecutive checks, settle.
      // Cap at 800ms as a hard fallback for very slow machines.
      let lastScrollY = window.scrollY;
      let steadyCount = 0;
      const pollInterval = setInterval(() => {
        const currentScrollY = window.scrollY;
        if (currentScrollY === lastScrollY) {
          steadyCount++;
          if (steadyCount >= 2) flushPending();
        } else {
          steadyCount = 0;
          lastScrollY = currentScrollY;
        }
      }, 50);
      const fallbackId = setTimeout(flushPending, 800);

      function flushPending() {
        clearInterval(pollInterval);
        clearTimeout(fallbackId);
        if (!scrollPending) return; // already flushed
        const pending = scrollPending;
        scrollPending = null;
        lockToLine(newLine);
        if (pending.pendingDelta !== 0) {
          const steps = Math.abs(pending.pendingDelta);
          const d = pending.pendingDelta > 0 ? 1 : -1;
          for (let i = 0; i < steps; i++) navigateLine(d);
        }
        saveState();
      }

      scrollPending = { pendingDelta: 0, timeoutId: fallbackId };
    }
  }

  document.addEventListener('keydown', (e) => {
    const tag = e.target.tagName;
    if (['INPUT','TEXTAREA','SELECT'].includes(tag) || e.target.isContentEditable) return;

    if (e.key === 'Escape') {
      if (state.pickMode) { exitPickMode(); return; }
      if (state.active)   { setActive(false); return; }
    }

    if (!state.active || state.pickMode) return;
    if (state.mouseMode) return;

    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const dir = e.key === 'ArrowDown' ? 1 : -1;

      // Fallback: no DOM blocks found — plain px movement
      if (getAllBlocks().length === 0) {
        state.lineY = Math.max(0,
          Math.min(window.innerHeight - state.stripHeight - 4, state.lineY + dir * state.step)
        );
        render(); saveState();
        return;
      }

      // If a smooth scroll is settling, queue delta and return
      if (scrollPending) {
        scrollPending.pendingDelta += dir;
        return;
      }

      if (state.mouseMode && !state.mouseLocked) {
        // Unlocked mouse mode — arrow keys nudge by step px
        state.lineY = Math.max(0,
          Math.min(window.innerHeight - state.stripHeight - 2,
            state.lineY + dir * state.step));
        render(); saveState();
      } else if (state.mouseMode && state.mouseLocked) {
        // Locked mouse mode — switch to DOM line navigation.
        // On first press snap lockedLine to nearest DOM line, then step from there.
        if (!lockedLine) {
          rebuildWindow();
          lockedLine = nearestLine(state.lineY + state.stripHeight / 2);
        }
        navigateLine(dir);
      } else {
        navigateLine(dir);
      }
    }
  }, true);

  // ═══════════════════════════════════════════════════════════════════════════
  // ACTIVATION HELPERS
  // ═══════════════════════════════════════════════════════════════════════════
  function activate() {
    buildOverlay();
    buildCaptureLayer();

    const metrics = detectLineMetrics();
    if (!state.stripHeightManual) state.stripHeight = metrics.stripHeight;
    state.step = metrics.lineHeight;
    if (metrics.nativeLineHeight > 0) state.nativeLineHeight = metrics.nativeLineHeight;

    // Index the window around the current scroll position
    lastWindowScrollY = window.scrollY;
    rebuildWindow();

    // Lock to the first visible line in the current viewport
    const firstVisible = allLines.find(ln => {
      const top = getLineTop(ln);
      return top >= 0 && top < window.innerHeight;
    });

    if (firstVisible) {
      lockedLine = firstVisible;
      state.lineY = Math.max(0, getLineTop(firstVisible) - 2);
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    if (state.mouseMode) {
      document.addEventListener('mousemove', onMouseMove, { passive: true });
      document.addEventListener('click', onMouseClick);
    }
    setActive(true);
  }

  function deactivate() {
    window.removeEventListener('scroll', onScroll);
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('click', onMouseClick);
    if (scrollPending) {
      clearTimeout(scrollPending.timeoutId);
      scrollPending = null;
    }
    lockedLine = null;
    // Always hide captureLayer on deactivation — mouse mode leaves it visible
    // to cover PDF embeds, but it must not persist after the overlay is off
    // or it will block all pointer events (selections, clicks, copy-paste).
    if (captureLayer) {
      captureLayer.style.display = 'none';
      captureLayer.style.cursor = 'crosshair'; // reset for next pick mode use
    }
    if (state.pickMode) exitPickMode();
    setActive(false);
  }

  function setActive(val) {
    state.active = val;
    render();
    saveState();
    chrome.runtime.sendMessage({ type: 'STATE_UPDATE', active: val }).catch(() => {});
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // PERSISTENCE
  // ═══════════════════════════════════════════════════════════════════════════
  function saveState() {
    chrome.storage.sync.set({
      active: state.active,
      lineY: state.lineY,
      stripHeight: state.stripHeight,
      step: state.step,
      tintColor: state.tintColor,
      tintOpacity: state.tintOpacity,
      underlineColor: state.underlineColor,
      underlineWidth: state.underlineWidth,
      linkedColors: state.linkedColors,
      scrollMode: state.scrollMode,
      fontOverride: state.fontOverride,
      letterSpacing: state.letterSpacing,
      lineHeightOverride: state.lineHeightOverride,
      mouseMode: state.mouseMode,
      stripTintEnabled: state.stripTintEnabled,
      stripTintColor:   state.stripTintColor,
      stripTintOpacity: state.stripTintOpacity,
      shadingEnabled: state.shadingEnabled,
      shadeColor:     state.shadeColor,
      shadeOpacity:    state.shadeOpacity,
      nativeLineHeight: state.nativeLineHeight,
      columnWidth:      state.columnWidth,
    });
  }

  function loadState(cb) {
    chrome.storage.sync.get([
      'active','lineY','stripHeight','stripHeightManual','step',
      'tintColor','tintOpacity','underlineColor','underlineWidth','linkedColors',
      'scrollMode',
      'stripTintEnabled','stripTintColor','stripTintOpacity',
      'fontOverride','letterSpacing','lineHeightOverride','mouseMode',
      'shadingEnabled','shadeColor','shadeOpacity',
      'nativeLineHeight','columnWidth',
    ], (data) => {
      if (data.active !== undefined)         state.active = data.active;
      if (data.lineY !== undefined)          state.lineY = data.lineY;
      if (data.stripHeight !== undefined)        state.stripHeight = data.stripHeight;
      if (data.stripHeightManual !== undefined)  state.stripHeightManual = data.stripHeightManual;
      if (data.step !== undefined)           state.step = data.step;
      if (data.tintColor !== undefined)      state.tintColor = data.tintColor;
      if (data.tintOpacity !== undefined)    state.tintOpacity = data.tintOpacity;
      if (data.underlineColor !== undefined) state.underlineColor = data.underlineColor;
      if (data.underlineWidth !== undefined) state.underlineWidth = data.underlineWidth;
      if (data.linkedColors !== undefined)   state.linkedColors = data.linkedColors;
      if (data.scrollMode !== undefined)       state.scrollMode = data.scrollMode;
      if (data.fontOverride !== undefined)     state.fontOverride = data.fontOverride;
      if (data.letterSpacing !== undefined)    state.letterSpacing = data.letterSpacing;
      if (data.lineHeightOverride !== undefined) state.lineHeightOverride = data.lineHeightOverride;
      if (data.mouseMode !== undefined)          state.mouseMode = data.mouseMode;
      if (data.stripTintEnabled !== undefined)   state.stripTintEnabled = data.stripTintEnabled;
      if (data.stripTintColor !== undefined)     state.stripTintColor = data.stripTintColor;
      if (data.stripTintOpacity !== undefined)   state.stripTintOpacity = data.stripTintOpacity;
      if (data.shadingEnabled !== undefined)   state.shadingEnabled = data.shadingEnabled;
      if (data.shadeColor !== undefined)       state.shadeColor = data.shadeColor;
      if (data.shadeOpacity !== undefined)     state.shadeOpacity = data.shadeOpacity;
      if (data.nativeLineHeight !== undefined) state.nativeLineHeight = data.nativeLineHeight;
      if (data.columnWidth !== undefined)      state.columnWidth = data.columnWidth;
      cb();
    });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // MESSAGES FROM POPUP
  // ═══════════════════════════════════════════════════════════════════════════
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {

    if (msg.type === 'TOGGLE_OVERLAY') {
      if (!state.active) {
        activate();
        sendResponse({ active: true, stripHeight: state.stripHeight, step: state.step, nativeLineHeight: state.nativeLineHeight });
      } else {
        deactivate();
        sendResponse({ active: false });
      }
    }

    if (msg.type === 'GET_STATE') {
      sendResponse({
        active: state.active,
        lineY: state.lineY,
        stripHeight: state.stripHeight,
        mouseMode: state.mouseMode,
        scrollMode: state.scrollMode,
        nativeLineHeight: state.nativeLineHeight,
      });
    }

    if (msg.type === 'ENTER_PICK_MODE') {
      buildOverlay();
      buildCaptureLayer();
      if (!state.active) {
        lastWindowScrollY = window.scrollY;
        rebuildWindow();
        window.addEventListener('scroll', onScroll, { passive: true });
        if (state.mouseMode) {
          document.addEventListener('mousemove', onMouseMove, { passive: true });
          document.addEventListener('click', onMouseClick);
        }
        state.active = true;
        render();
      }
      enterPickMode();
      sendResponse({ ok: true });
    }

    if (msg.type === 'UPDATE_SETTINGS') {
      const s = msg.settings;
      if (s.tintColor !== undefined && state.linkedColors && s.linkedColors !== false) {
        s.underlineColor = deriveUnderlineColor(s.tintColor);
      }
      if (s.linkedColors === true) {
        s.underlineColor = deriveUnderlineColor(s.tintColor ?? state.tintColor);
      }
      const wasMouseMode = state.mouseMode;
      if (s.stripHeight !== undefined) s.stripHeightManual = true;
      Object.assign(state, s);
      if (state.mouseMode && !wasMouseMode) {
        enterMouseMode();
      } else if (!state.mouseMode && wasMouseMode) {
        exitMouseMode();
      }
      render();
      applyFontOverride();
      applyShading();
      applyColumnWidth();
      saveState();
      sendResponse({ ok: true, underlineColor: state.underlineColor });
    }

    if (msg.type === 'DETECT_METRICS') {
      const m = detectLineMetrics();
      // Always apply when explicitly requested (e.g. reset button) —
      // this is the intentional auto-detect path, not an override.
      state.stripHeight = m.stripHeight;
      state.stripHeightManual = false;
      state.step = m.lineHeight;
      if (m.nativeLineHeight > 0) state.nativeLineHeight = m.nativeLineHeight;
      render();
      saveState();
      sendResponse(m);
    }

    return true;
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // RESIZE / ZOOM HANDLER
  // Chrome fires 'resize' when the user zooms (Ctrl+/Ctrl-). We detect zoom
  // specifically by tracking devicePixelRatio — a resize without a DPR change
  // is just a window resize and doesn't need metric re-detection.
  // ═══════════════════════════════════════════════════════════════════════════
  let lastDevicePixelRatio = window.devicePixelRatio;

  // Debounced so we don't thrash during a continuous zoom gesture
  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (!state.active) return;

      const zoomed = window.devicePixelRatio !== lastDevicePixelRatio;
      lastDevicePixelRatio = window.devicePixelRatio;

      if (zoomed) {
        // Re-detect metrics since font rendering changed
        const metrics = detectLineMetrics();
        if (!state.stripHeightManual) state.stripHeight = metrics.stripHeight;
        state.step = metrics.lineHeight;
      }

      // Either way: invalidate caches and re-lock to the current element
      allBlocksCache = null;
      lastWindowScrollY = -Infinity;
      rebuildWindow();

      if (lockedLine) {
        const top = getLineTop(lockedLine);
        if (state.scrollMode === 'fixed') {
          // Fixed mode: lineY is the viewport anchor — scroll the page to bring
          // the element back to lineY after reflow, don't move the strip.
          if (top > -window.innerHeight && top < window.innerHeight * 2) {
            const targetScrollTop = (top + window.scrollY) - state.lineY;
            if (targetScrollTop >= 0) {
              suppressScrollLock = true;
              window.scrollTo({ top: targetScrollTop, behavior: 'instant' });
              requestAnimationFrame(() => requestAnimationFrame(() => {
                suppressScrollLock = false;
                if (!state.stripHeightManual) {
                  const lh = getLineHeight(lockedLine);
                  if (lh > 0) state.stripHeight = lh + 6;
                }
                render();
                saveState();
              }));
            }
          } else {
            // Element out of range — re-lock nearest, keep lineY fixed
            const nearest = nearestLine(state.lineY + state.stripHeight / 2);
            if (nearest) lockedLine = nearest;
            render();
            saveState();
          }
        } else {
          // Center mode: snap lineY to wherever the element ended up after reflow
          if (top > -window.innerHeight && top < window.innerHeight * 2) {
            state.lineY = Math.max(0, top - 2);
          } else {
            const nearest = nearestLine(window.innerHeight / 2);
            if (nearest) { lockedLine = nearest; state.lineY = Math.max(0, getLineTop(nearest) - 2); }
          }
          render();
          saveState();
        }
      }
    }, 150);
  }, { passive: true });

  // ═══════════════════════════════════════════════════════════════════════════
  // INIT — bail out on non-content pages (chrome://, PDFs, extension pages)
  // ═══════════════════════════════════════════════════════════════════════════
  if (!document.body || document.body.tagName !== 'BODY') return;

  // Watch for our style elements being removed by site JS (SPAs often do this)
  // and re-inject them when that happens.
  const headObserver = new MutationObserver(() => {
    const fontMissing = !document.getElementById('__reading-guide-font__');
    const typoMissing = !document.getElementById('__reading-guide-typo__');
    const shadeMissing  = !document.getElementById('__reading-guide-shade__');
    const columnMissing = !document.getElementById('__reading-guide-column__');
    if (fontMissing || typoMissing || shadeMissing || columnMissing) {
      if (fontMissing)   fontStyleEl   = null;
      if (typoMissing)   typoStyleEl   = null;
      if (shadeMissing)  shadeStyleEl  = null;
      if (columnMissing) columnStyleEl = null;
      applyFontOverride();
      applyShading();
      applyColumnWidth();
    }
  });

  loadState(() => {
    buildOverlay();
    buildCaptureLayer();
    applyFontOverride();
    applyShading();
    applyColumnWidth();

    headObserver.observe(document.head || document.documentElement, {
      childList: true, subtree: false,
    });

    if (state.active) {
      lastWindowScrollY = window.scrollY;
      rebuildWindow();
      lockedLine = nearestLine(state.lineY + state.stripHeight / 2);
      window.addEventListener('scroll', onScroll, { passive: true });
      render();
    }
  });

})();