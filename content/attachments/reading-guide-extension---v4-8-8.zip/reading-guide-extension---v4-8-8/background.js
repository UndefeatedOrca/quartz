chrome.commands.onCommand.addListener((command) => {
  if (command === 'toggle-overlay') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return;
      // Alt+R: if overlay is off, activate and enter pick mode.
      // If already on, enter pick mode to reposition.
      // Esc still turns the overlay off from the page.
      chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_STATE' }, (res) => {
        if (chrome.runtime.lastError || !res) return;
        chrome.tabs.sendMessage(tabs[0].id, { type: 'ENTER_PICK_MODE' });
      });
    });
  }
});