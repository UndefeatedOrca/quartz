# Beeline Reader Chrome Extension

A Chrome extension that improves reading speed and comprehension by applying smooth color gradients to text on web pages.

## Features

- **Smooth Color Gradients**: Creates a visual rhythm that guides your eyes through text
- **Customizable Colors**: Choose your own gradient colors (default: red and teal)
- **Adjustable Cycle Length**: Control how quickly colors transition (20-500 characters)
- **Live Preview**: See changes in real-time before applying them
- **Works Everywhere**: Applies to all websites
- **Performance Optimized**: Efficient text processing that doesn't slow down pages

## Installation

1. Download or clone this repository
2. Create an `icons` folder in the extension directory
3. Add three PNG icon files:
   - `icon16.png` (16x16 pixels)
   - `icon48.png` (48x48 pixels)
   - `icon128.png` (128x128 pixels)
4. Open Chrome and navigate to `chrome://extensions/`
5. Enable "Developer mode" (toggle in top-right corner)
6. Click "Load unpacked"
7. Select the extension directory

## File Structure

```
beeline-reader/
├── manifest.json          # Extension configuration
├── content.js            # Main script that applies the effect
├── popup.html            # Popup interface
├── popup.js              # Popup functionality
├── options.html          # Settings page
├── options.js            # Settings page functionality
├── icons/
│   ├── icon16.png       # Small icon
│   ├── icon48.png       # Medium icon
│   └── icon128.png      # Large icon
└── README.md            # This file
```

## Usage

### Quick Start
1. Click the Beeline Reader icon in your Chrome toolbar
2. Toggle "Enable Beeline Effect" to turn it on
3. Refresh any open web pages to see the effect

### Customization
1. Click the extension icon or right-click and select "Options"
2. Adjust the gradient colors using the color pickers
3. Modify the cycle length with the slider
4. Watch the preview update in real-time
5. Click "Save Settings" on the options page

### Settings

- **Enable/Disable**: Toggle the effect on or off globally
- **Color 1**: First gradient color (default: red #FF6B6B)
- **Color 2**: Second gradient color (default: teal #4ECDC4)
- **Cycle Length**: Characters per color cycle (default: 125)

## How It Works

The extension applies a smooth gradient pattern that cycles through:
1. Black → Color 1 (0-25% of cycle)
2. Color 1 → Black (25-50% of cycle)
3. Black → Color 2 (50-75% of cycle)
4. Color 2 → Black (75-100% of cycle)

This creates a continuous wave pattern that helps guide your eyes naturally through text, improving reading speed and reducing eye strain.

## Creating Icons

You'll need to create three icon files. Here are some options:

### Option 1: Simple Design
Create a simple icon with overlapping colored waves or gradient bars representing the Beeline effect.

### Option 2: Use an Icon Generator
Use a tool like:
- [Favicon.io](https://favicon.io/)
- [RealFaviconGenerator](https://realfavicongenerator.net/)
- Canva or Figma

### Option 3: Placeholder Icons
For testing, you can create solid color squares in any image editor:
- 16x16px - Small icon for toolbar
- 48x48px - Medium icon for extension management
- 128x128px - Large icon for Chrome Web Store

## Technical Details

- **Manifest Version**: V3
- **Permissions**: Storage, Active Tab, All URLs
- **Storage**: Chrome Sync Storage for settings
- **Processing**: Character-by-character text processing with inline element support
- **Gradient**: RGB interpolation between colors

## Performance

The extension is optimized for performance:
- Processes text only once per page load
- Efficient character-by-character processing
- Maintains original page structure
- Minimal memory footprint

## Browser Compatibility

- Chrome (Manifest V3)
- Edge (Chromium-based)
- Brave
- Other Chromium-based browsers

## Known Limitations

- Dynamically loaded content (infinite scroll) may need page refresh
- Some websites with heavy JavaScript manipulation may conflict
- Video captions and canvas text are not affected

## Troubleshooting

**Effect not appearing:**
- Make sure the toggle is enabled
- Refresh the page after enabling
- Check if the website has any script blockers

**Performance issues:**
- Try increasing the cycle length for faster processing
- Disable on particularly heavy websites

**Colors not showing:**
- Verify color pickers have valid hex values
- Check if the website has !important CSS rules overriding colors

## Privacy

This extension:
- ✅ Does NOT collect any data
- ✅ Does NOT track browsing history
- ✅ Does NOT send data to external servers
- ✅ Only stores user preferences locally

## License

This is an educational project. Feel free to modify and distribute.

## Credits

Inspired by the original Beeline Reader by Beeline Learning, which pioneered the use of color gradients to improve reading speed and comprehension.