// Background service worker for Beeline Reader

// Handle keyboard shortcut
chrome.commands.onCommand.addListener((command) => {
  if (command === 'toggle-beeline') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (tabs[0]) {
        const tab = tabs[0];
        const url = new URL(tab.url);
        const domain = url.hostname;
        
        // Get current settings
        const data = await chrome.storage.sync.get(['enabled', 'enabledSites']);
        const enabledSites = data.enabledSites || {};
        const globalEnabled = data.enabled !== false;
        
        // Determine current state for this site
        const currentlyEnabled = globalEnabled || enabledSites[domain] === true;
        
        // Toggle: if currently enabled, disable for this site; if disabled, enable for this site
        if (currentlyEnabled) {
          // Disable for this site specifically
          enabledSites[domain] = false;
        } else {
          // Enable for this site specifically
          enabledSites[domain] = true;
        }
        
        await chrome.storage.sync.set({ enabledSites });
        
        // Reload the tab to apply changes
        chrome.tabs.reload(tab.id);
      }
    });
  }
});