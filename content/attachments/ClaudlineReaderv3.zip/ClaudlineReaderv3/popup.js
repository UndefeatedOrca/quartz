// Popup script for Beeline Reader

const enableToggle = document.getElementById('enableToggle');
const color1Input = document.getElementById('color1');
const color2Input = document.getElementById('color2');
const color1Value = document.getElementById('color1Value');
const color2Value = document.getElementById('color2Value');
const wordsPerCycleInput = document.getElementById('wordsPerCycle');
const wordsPerCycleValue = document.getElementById('wordsPerCycleValue');
const intensityInput = document.getElementById('intensity');
const intensityValue = document.getElementById('intensityValue');
const siteToggle = document.getElementById('siteToggle');
const currentSite = document.getElementById('currentSite');
const preview = document.getElementById('preview');

let currentDomain = '';

// Get current domain
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs[0]) {
    const url = new URL(tabs[0].url);
    currentDomain = url.hostname;
    currentSite.textContent = currentDomain;
  }
});

// Load saved settings
chrome.storage.sync.get(['enabled', 'color1', 'color2', 'wordsPerCycle', 'intensity', 'enabledSites'], (data) => {
  enableToggle.checked = data.enabled !== false;
  color1Input.value = data.color1 || '#FF6B6B';
  color2Input.value = data.color2 || '#4ECDC4';
  wordsPerCycleInput.value = data.wordsPerCycle || 25;
  intensityInput.value = data.intensity !== undefined ? data.intensity : 1.0;
  
  const enabledSites = data.enabledSites || {};
  const globalEnabled = data.enabled !== false;
  
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      const url = new URL(tabs[0].url);
      const domain = url.hostname;
      
      // Determine if this site is enabled
      let siteEnabled;
      if (enabledSites[domain] === false) {
        siteEnabled = false;
      } else if (enabledSites[domain] === true) {
        siteEnabled = true;
      } else {
        siteEnabled = globalEnabled;
      }
      
      siteToggle.checked = siteEnabled;
    }
  });
  
  color1Value.textContent = color1Input.value.toUpperCase();
  color2Value.textContent = color2Input.value.toUpperCase();
  wordsPerCycleValue.textContent = wordsPerCycleInput.value;
  intensityValue.textContent = Math.round(intensityInput.value * 100);
  
  updatePreview();
});

// Save settings when changed
enableToggle.addEventListener('change', () => {
  chrome.storage.sync.set({ enabled: enableToggle.checked });
});

color1Input.addEventListener('input', () => {
  color1Value.textContent = color1Input.value.toUpperCase();
  chrome.storage.sync.set({ color1: color1Input.value });
  updatePreview();
});

color2Input.addEventListener('input', () => {
  color2Value.textContent = color2Input.value.toUpperCase();
  chrome.storage.sync.set({ color2: color2Input.value });
  updatePreview();
});

wordsPerCycleInput.addEventListener('input', () => {
  wordsPerCycleValue.textContent = wordsPerCycleInput.value;
  chrome.storage.sync.set({ wordsPerCycle: parseInt(wordsPerCycleInput.value) });
  updatePreview();
});

intensityInput.addEventListener('input', () => {
  intensityValue.textContent = Math.round(intensityInput.value * 100);
  chrome.storage.sync.set({ intensity: parseFloat(intensityInput.value) });
  updatePreview();
});

siteToggle.addEventListener('change', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    if (tabs[0]) {
      const url = new URL(tabs[0].url);
      const domain = url.hostname;
      
      const data = await chrome.storage.sync.get(['enabledSites', 'enabled']);
      const enabledSites = data.enabledSites || {};
      const globalEnabled = data.enabled !== false;
      
      // If toggling on and it matches global state, remove the override
      // If toggling to a different state, set the override
      if (siteToggle.checked === globalEnabled) {
        delete enabledSites[domain];
      } else {
        enabledSites[domain] = siteToggle.checked;
      }
      
      await chrome.storage.sync.set({ enabledSites });
    }
  });
});

// Preview functionality
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : { r: 0, g: 0, b: 0 };
}

function interpolateColor(color1, color2, factor, intensity) {
  const c1 = hexToRgb(color1);
  const c2 = hexToRgb(color2);
  
  const r = Math.round(c1.r + (c2.r - c1.r) * factor);
  const g = Math.round(c1.g + (c2.g - c1.g) * factor);
  const b = Math.round(c1.b + (c2.b - c1.b) * factor);
  
  // Apply intensity
  const black = 0;
  const finalR = Math.round(black + (r - black) * intensity);
  const finalG = Math.round(black + (g - black) * intensity);
  const finalB = Math.round(black + (b - black) * intensity);
  
  return `rgb(${finalR}, ${finalG}, ${finalB})`;
}

function getColorForPosition(position, c1, c2, wordsPerCycle, intensity) {
  const black = '#000000';
  const fullCycle = wordsPerCycle * 2;
  const posInCycle = position % fullCycle;
  const quarter = wordsPerCycle / 2;
  
  if (posInCycle < quarter) {
    const factor = posInCycle / quarter;
    return interpolateColor(black, c1, factor, intensity);
  } else if (posInCycle < wordsPerCycle) {
    const factor = (posInCycle - quarter) / quarter;
    return interpolateColor(c1, black, factor, intensity);
  } else if (posInCycle < wordsPerCycle + quarter) {
    const factor = (posInCycle - wordsPerCycle) / quarter;
    return interpolateColor(black, c2, factor, intensity);
  } else {
    const factor = (posInCycle - wordsPerCycle - quarter) / quarter;
    return interpolateColor(c2, black, factor, intensity);
  }
}

function updatePreview() {
  const text = preview.textContent;
  const c1 = color1Input.value;
  const c2 = color2Input.value;
  const wordsPerCycle = parseInt(wordsPerCycleInput.value);
  const intensity = parseFloat(intensityInput.value);
  
  // Tokenize into words
  const words = text.split(/(\s+)/);
  
  preview.innerHTML = '';
  let wordCount = 0;
  
  for (const token of words) {
    if (/^\s+$/.test(token)) {
      // It's whitespace
      preview.appendChild(document.createTextNode(token));
    } else if (token) {
      // It's a word
      const span = document.createElement('span');
      span.textContent = token;
      span.style.color = getColorForPosition(wordCount, c1, c2, wordsPerCycle, intensity);
      preview.appendChild(span);
      wordCount++;
    }
  }
}