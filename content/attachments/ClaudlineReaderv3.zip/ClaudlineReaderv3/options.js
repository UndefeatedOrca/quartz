// Options page script for Beeline Reader

const enableToggle = document.getElementById('enableToggle');
const color1Input = document.getElementById('color1');
const color2Input = document.getElementById('color2');
const color1Value = document.getElementById('color1Value');
const color2Value = document.getElementById('color2Value');
const wordsPerCycleInput = document.getElementById('wordsPerCycle');
const wordsPerCycleValue = document.getElementById('wordsPerCycleValue');
const intensityInput = document.getElementById('intensity');
const intensityValue = document.getElementById('intensityValue');
const skipSelectorsInput = document.getElementById('skipSelectors');
const preview = document.getElementById('preview');
const saveButton = document.getElementById('saveButton');
const resetButton = document.getElementById('resetButton');
const saveMessage = document.getElementById('saveMessage');

const defaults = {
  enabled: true,
  color1: '#FF6B6B',
  color2: '#4ECDC4',
  wordsPerCycle: 25,
  intensity: 1.0,
  skipSelectors: []
};

// Load saved settings
function loadSettings() {
  chrome.storage.sync.get(['enabled', 'color1', 'color2', 'wordsPerCycle', 'intensity', 'skipSelectors'], (data) => {
    enableToggle.checked = data.enabled !== false;
    color1Input.value = data.color1 || defaults.color1;
    color2Input.value = data.color2 || defaults.color2;
    wordsPerCycleInput.value = data.wordsPerCycle || defaults.wordsPerCycle;
    intensityInput.value = data.intensity !== undefined ? data.intensity : defaults.intensity;
    
    const skipSelectors = data.skipSelectors || defaults.skipSelectors;
    skipSelectorsInput.value = skipSelectors.join('\n');
    
    updateColorValues();
    updateWordsPerCycleValue();
    updateIntensityValue();
    updatePreview();
  });
}

function updateColorValues() {
  color1Value.textContent = color1Input.value.toUpperCase();
  color2Value.textContent = color2Input.value.toUpperCase();
}

function updateWordsPerCycleValue() {
  wordsPerCycleValue.textContent = wordsPerCycleInput.value;
}

function updateIntensityValue() {
  intensityValue.textContent = Math.round(intensityInput.value * 100);
}

// Save all settings
function saveSettings() {
  const skipSelectorsText = skipSelectorsInput.value;
  const skipSelectors = skipSelectorsText
    .split('\n')
    .map(s => s.trim())
    .filter(s => s.length > 0);
  
  const settings = {
    enabled: enableToggle.checked,
    color1: color1Input.value,
    color2: color2Input.value,
    wordsPerCycle: parseInt(wordsPerCycleInput.value),
    intensity: parseFloat(intensityInput.value),
    skipSelectors: skipSelectors
  };
  
  chrome.storage.sync.set(settings, () => {
    showSaveMessage();
  });
}

// Reset to defaults
function resetSettings() {
  enableToggle.checked = defaults.enabled;
  color1Input.value = defaults.color1;
  color2Input.value = defaults.color2;
  wordsPerCycleInput.value = defaults.wordsPerCycle;
  intensityInput.value = defaults.intensity;
  skipSelectorsInput.value = defaults.skipSelectors.join('\n');
  
  updateColorValues();
  updateWordsPerCycleValue();
  updateIntensityValue();
  updatePreview();
  
  saveSettings();
}

// Show save confirmation message
function showSaveMessage() {
  saveMessage.classList.add('show');
  setTimeout(() => {
    saveMessage.classList.remove('show');
  }, 3000);
}

// Event listeners
enableToggle.addEventListener('change', saveSettings);

color1Input.addEventListener('input', () => {
  updateColorValues();
  updatePreview();
});

color2Input.addEventListener('input', () => {
  updateColorValues();
  updatePreview();
});

wordsPerCycleInput.addEventListener('input', () => {
  updateWordsPerCycleValue();
  updatePreview();
});

intensityInput.addEventListener('input', () => {
  updateIntensityValue();
  updatePreview();
});

skipSelectorsInput.addEventListener('input', () => {
  // No preview update needed for skip selectors
});

saveButton.addEventListener('click', saveSettings);
resetButton.addEventListener('click', resetSettings);

// Preview functionality
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : { r: 0, g: 0, b: 0 };
}

function interpolateColor(color1, color2, factor, intensity) {
  const c1 = hexToRgb(color1);
  const c2 = hexToRgb(color2);
  
  const r = Math.round(c1.r + (c2.r - c1.r) * factor);
  const g = Math.round(c1.g + (c2.g - c1.g) * factor);
  const b = Math.round(c1.b + (c2.b - c1.b) * factor);
  
  // Apply intensity
  const black = 0;
  const finalR = Math.round(black + (r - black) * intensity);
  const finalG = Math.round(black + (g - black) * intensity);
  const finalB = Math.round(black + (b - black) * intensity);
  
  return `rgb(${finalR}, ${finalG}, ${finalB})`;
}

function getColorForPosition(position, c1, c2, wordsPerCycle, intensity) {
  const black = '#000000';
  const fullCycle = wordsPerCycle * 2;
  const posInCycle = position % fullCycle;
  const quarter = wordsPerCycle / 2;
  
  if (posInCycle < quarter) {
    const factor = posInCycle / quarter;
    return interpolateColor(black, c1, factor, intensity);
  } else if (posInCycle < wordsPerCycle) {
    const factor = (posInCycle - quarter) / quarter;
    return interpolateColor(c1, black, factor, intensity);
  } else if (posInCycle < wordsPerCycle + quarter) {
    const factor = (posInCycle - wordsPerCycle) / quarter;
    return interpolateColor(black, c2, factor, intensity);
  } else {
    const factor = (posInCycle - wordsPerCycle - quarter) / quarter;
    return interpolateColor(c2, black, factor, intensity);
  }
}

function updatePreview() {
  const text = preview.textContent;
  const c1 = color1Input.value;
  const c2 = color2Input.value;
  const wordsPerCycle = parseInt(wordsPerCycleInput.value);
  const intensity = parseFloat(intensityInput.value);
  
  // Tokenize into words
  const words = text.split(/(\s+)/);
  
  preview.innerHTML = '';
  let wordCount = 0;
  
  for (const token of words) {
    if (/^\s+$/.test(token)) {
      // It's whitespace
      preview.appendChild(document.createTextNode(token));
    } else if (token) {
      // It's a word
      const span = document.createElement('span');
      span.textContent = token;
      span.style.color = getColorForPosition(wordCount, c1, c2, wordsPerCycle, intensity);
      preview.appendChild(span);
      wordCount++;
    }
  }
}

// Initialize
loadSettings();