// Content script for applying Beeline Reader effect - Word-based version

let isEnabled = false;
let color1 = '#FF6B6B';
let color2 = '#4ECDC4';
let wordsPerCycle = 25;
let intensity = 1.0;
let skipSelectors = [];
let processedNodes = new WeakSet();
let isProcessing = false;
let hasProcessedPage = false;
let isDarkMode = false;

// Load settings and apply effect
chrome.storage.sync.get(['enabled', 'color1', 'color2', 'wordsPerCycle', 'intensity', 'enabledSites', 'skipSelectors'], (data) => {
  const domain = location.hostname;
  const enabledSites = data.enabledSites || {};
  const globalEnabled = data.enabled !== false;
  
  // Check if enabled: global on OR site specifically enabled, AND site not specifically disabled
  if (enabledSites[domain] === false) {
    isEnabled = false;
  } else if (enabledSites[domain] === true) {
    isEnabled = true;
  } else {
    isEnabled = globalEnabled;
  }
  
  color1 = data.color1 || '#FF6B6B';
  color2 = data.color2 || '#4ECDC4';
  wordsPerCycle = data.wordsPerCycle || 25;
  intensity = data.intensity !== undefined ? data.intensity : 1.0;
  skipSelectors = data.skipSelectors || [];
  
  if (isEnabled) {
    // Only process if tab is visible or becomes visible
    if (document.visibilityState === 'visible') {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', applyBeelineEffect);
      } else {
        applyBeelineEffect();
      }
    }
  }
});

// Process when tab becomes visible
document.addEventListener('visibilitychange', () => {
  if (isEnabled && document.visibilityState === 'visible' && !hasProcessedPage && !isProcessing) {
    applyBeelineEffect();
  }
});

// Listen for settings changes
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'sync') {
    let needsReapply = false;
    
    if (changes.enabled || changes.enabledSites) {
      const domain = location.hostname;
      chrome.storage.sync.get(['enabled', 'enabledSites'], (data) => {
        const enabledSites = data.enabledSites || {};
        const globalEnabled = data.enabled !== false;
        
        if (enabledSites[domain] === false) {
          isEnabled = false;
        } else if (enabledSites[domain] === true) {
          isEnabled = true;
        } else {
          isEnabled = globalEnabled;
        }
        
        location.reload();
      });
      return;
    }
    if (changes.color1) {
      color1 = changes.color1.newValue;
      needsReapply = true;
    }
    if (changes.color2) {
      color2 = changes.color2.newValue;
      needsReapply = true;
    }
    if (changes.wordsPerCycle) {
      wordsPerCycle = changes.wordsPerCycle.newValue;
      needsReapply = true;
    }
    if (changes.intensity) {
      intensity = changes.intensity.newValue;
      needsReapply = true;
    }
    if (changes.skipSelectors) {
      skipSelectors = changes.skipSelectors.newValue;
      needsReapply = true;
    }
    
    if (needsReapply) {
      location.reload();
    }
  }
});

// Detect if page uses dark mode
function detectDarkMode() {
  const body = document.body;
  if (!body) return false;
  
  // First check body background
  let bgColor = window.getComputedStyle(body).backgroundColor;
  
  // If transparent or rgba with alpha 0, check html element
  if (bgColor === 'transparent' || bgColor === 'rgba(0, 0, 0, 0)') {
    const html = document.documentElement;
    bgColor = window.getComputedStyle(html).backgroundColor;
  }
  
  // Still transparent? Check the actual default text color instead
  if (bgColor === 'transparent' || bgColor === 'rgba(0, 0, 0, 0)') {
    const textColor = window.getComputedStyle(body).color;
    const rgb = textColor.match(/\d+/g);
    if (!rgb || rgb.length < 3) return false;
    
    const r = parseInt(rgb[0]);
    const g = parseInt(rgb[1]);
    const b = parseInt(rgb[2]);
    
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b);
    
    // If text is light colored (high luminance), it's dark mode
    return luminance > 128;
  }
  
  // Parse background RGB values
  const rgb = bgColor.match(/\d+/g);
  if (!rgb || rgb.length < 3) return false;
  
  const r = parseInt(rgb[0]);
  const g = parseInt(rgb[1]);
  const b = parseInt(rgb[2]);
  
  // Calculate luminance
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b);
  
  // If background luminance is below 128, it's dark mode
  return luminance < 128;
}

// Convert hex color to RGB object
function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : { r: 0, g: 0, b: 0 };
}

// Interpolate between two colors with intensity
function interpolateColor(color1, color2, factor) {
  const c1 = hexToRgb(color1);
  const c2 = hexToRgb(color2);
  
  const r = Math.round(c1.r + (c2.r - c1.r) * factor);
  const g = Math.round(c1.g + (c2.g - c1.g) * factor);
  const b = Math.round(c1.b + (c2.b - c1.b) * factor);
  
  const baseValue = isDarkMode ? 255 : 0;
  
  // For dark mode, invert intensity behavior
  // High intensity = more visible (closer to white)
  // Low intensity = more colorful (further from white)
  const effectiveIntensity = isDarkMode ? (intensity) : intensity;
  
  const finalR = Math.round(baseValue + (r - baseValue) * effectiveIntensity);
  const finalG = Math.round(baseValue + (g - baseValue) * effectiveIntensity);
  const finalB = Math.round(baseValue + (b - baseValue) * effectiveIntensity);
  
  return `rgb(${finalR}, ${finalG}, ${finalB})`;
}

// Get color for a word at a specific position
function getColorForPosition(position) {
  const baseColor = isDarkMode ? '#FFFFFF' : '#000000';
  const fullCycle = wordsPerCycle * 2;
  const posInCycle = position % fullCycle;
  const quarter = wordsPerCycle / 2;
  
  if (posInCycle < quarter) {
    const factor = posInCycle / quarter;
    return interpolateColor(baseColor, color1, factor);
  } else if (posInCycle < wordsPerCycle) {
    const factor = (posInCycle - quarter) / quarter;
    return interpolateColor(color1, baseColor, factor);
  } else if (posInCycle < wordsPerCycle + quarter) {
    const factor = (posInCycle - wordsPerCycle) / quarter;
    return interpolateColor(baseColor, color2, factor);
  } else {
    const factor = (posInCycle - wordsPerCycle - quarter) / quarter;
    return interpolateColor(color2, baseColor, factor);
  }
}

// Check if element should be skipped
function shouldSkipElement(element) {
  if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;
  
  const defaultSkipTags = ['SCRIPT', 'STYLE', 'NOSCRIPT', 'IFRAME', 'CANVAS', 'SVG', 'VIDEO', 'AUDIO', 'OBJECT', 'EMBED'];
  if (defaultSkipTags.includes(element.nodeName)) return true;
  
  // Check custom skip selectors
  if (skipSelectors && skipSelectors.length > 0) {
    try {
      for (const selector of skipSelectors) {
        if (selector.trim() && element.matches(selector.trim())) {
          return true;
        }
      }
    } catch (e) {
      // Invalid selector, ignore
    }
  }
  
  return false;
}

// Check if element is block-level
function isBlockElement(node) {
  if (node.nodeType !== Node.ELEMENT_NODE) return false;
  
  const blockElements = ['P', 'DIV', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 
                         'LI', 'UL', 'OL', 'BLOCKQUOTE', 'PRE', 'HR', 
                         'TABLE', 'TR', 'TD', 'TH', 'HEADER', 'FOOTER', 
                         'SECTION', 'ARTICLE', 'NAV', 'ASIDE', 'MAIN'];
  
  return blockElements.includes(node.nodeName);
}

// Tokenize text into words and spaces
function tokenize(text) {
  const tokens = [];
  let currentWord = '';
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    
    if (/\s/.test(char)) {
      if (currentWord) {
        tokens.push({ type: 'word', value: currentWord });
        currentWord = '';
      }
      tokens.push({ type: 'space', value: char });
    } else {
      currentWord += char;
    }
  }
  
  if (currentWord) {
    tokens.push({ type: 'word', value: currentWord });
  }
  
  return tokens;
}

// Process text node with gradient (word-based)
function processTextNode(textNode, startPosition) {
  const text = textNode.textContent;
  if (!text.trim()) return startPosition;
  
  const parent = textNode.parentNode;
  if (!parent || shouldSkipElement(parent)) return startPosition;
  
  // Check if already processed
  if (parent.hasAttribute && parent.hasAttribute('data-beeline-processed')) {
    return startPosition;
  }
  
  const tokens = tokenize(text);
  const fragment = document.createDocumentFragment();
  let wordCount = startPosition;
  
  for (const token of tokens) {
    if (token.type === 'space') {
      fragment.appendChild(document.createTextNode(token.value));
    } else {
      // token.type === 'word'
      const span = document.createElement('span');
      span.textContent = token.value;
      span.style.color = getColorForPosition(wordCount);
      span.style.display = 'inline';
      span.setAttribute('data-beeline', 'true');
      fragment.appendChild(span);
      wordCount++;
    }
  }
  
  try {
    parent.replaceChild(fragment, textNode);
  } catch (e) {
    console.warn('Beeline: Failed to process text node', e);
    return wordCount;
  }
  
  return wordCount;
}

// Process element and children recursively
function processElement(element, wordPosition = 0, depth = 0) {
  // Limit recursion depth
  if (depth > 100) return wordPosition;
  
  if (shouldSkipElement(element)) return wordPosition;
  
  // Skip if already processed
  if (element.hasAttribute && element.hasAttribute('data-beeline-processed')) {
    return wordPosition;
  }
  
  let position = wordPosition;
  const childNodes = Array.from(element.childNodes);
  
  for (const node of childNodes) {
    if (node.nodeType === Node.TEXT_NODE) {
      position = processTextNode(node, position);
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      if (isBlockElement(node)) {
        // Reset position for block elements
        processElement(node, 0, depth + 1);
      } else {
        // Continue position for inline elements
        position = processElement(node, position, depth + 1);
      }
    }
  }
  
  // Mark as processed
  if (element.setAttribute) {
    element.setAttribute('data-beeline-processed', 'true');
  }
  
  return position;
}

// Apply Beeline effect to the page
function applyBeelineEffect() {
  if (isProcessing || hasProcessedPage) return;
  isProcessing = true;
  
  // Detect dark mode before processing
  isDarkMode = detectDarkMode();
  console.log(`Beeline: Starting to apply effect (word-based, ${isDarkMode ? 'dark' : 'light'} mode detected)...`);
  
  try {
    const body = document.body;
    if (!body) {
      console.warn('Beeline: Document body not found');
      isProcessing = false;
      return;
    }
    
    const startTime = Date.now();
    
    // Get all text-containing elements
    const walker = document.createTreeWalker(
      body,
      NodeFilter.SHOW_ELEMENT,
      {
        acceptNode: function(node) {
          if (shouldSkipElement(node)) return NodeFilter.FILTER_REJECT;
          if (node.hasAttribute && node.hasAttribute('data-beeline-processed')) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );
    
    const elementsToProcess = [];
    let currentNode;
    
    while (currentNode = walker.nextNode()) {
      if (isBlockElement(currentNode)) {
        elementsToProcess.push(currentNode);
      }
    }
    
    console.log(`Beeline: Found ${elementsToProcess.length} elements to process`);
    
    // Process in chunks
    let index = 0;
    const chunkSize = 10;
    
    function processChunk() {
      const chunk = elementsToProcess.slice(index, index + chunkSize);
      
      for (const element of chunk) {
        try {
          processElement(element, 0);
        } catch (e) {
          console.warn('Beeline: Error processing element', e);
        }
      }
      
      index += chunkSize;
      
      if (index < elementsToProcess.length) {
        // Continue processing
        if ('requestIdleCallback' in window) {
          requestIdleCallback(processChunk, { timeout: 100 });
        } else {
          setTimeout(processChunk, 10);
        }
      } else {
        const elapsed = Date.now() - startTime;
        console.log(`Beeline: Finished processing in ${elapsed}ms`);
        isProcessing = false;
        hasProcessedPage = true;
      }
    }
    
    processChunk();
    
  } catch (e) {
    console.error('Beeline: Error applying effect', e);
    isProcessing = false;
  }
}